from flask import Flask, render_template, redirect, url_for, request, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from sqlalchemy import func, text
from sqlalchemy.exc import SQLAlchemyError
from models import db, User, PastoralVisit, Event, Donation, Attendance, Expense
from config import Config
from functools import wraps
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
database_initialized = False

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
csrf = CSRFProtect(app)

# Inject csrf_token into template context
@app.context_processor
def inject_csrf_token():
    from flask_wtf.csrf import generate_csrf
    return dict(csrf_token=generate_csrf)

login_manager = LoginManager(app)
login_manager.login_view = 'login'


def ensure_database_schema():
    """Apply small SQLite schema updates for existing local databases."""
    migrations = {
        'event': [
            ('updated_at', 'DATETIME'),
        ],
        'expense': [
            ('updated_at', 'DATETIME'),
        ],
        'pastoral_visit': [
            ('updated_at', 'DATETIME'),
        ],
    }

    with db.engine.begin() as connection:
        for table_name, columns in migrations.items():
            existing_columns = {
                row[1]
                for row in connection.execute(text(f'PRAGMA table_info({table_name})'))
            }

            for column_name, column_type in columns:
                if column_name not in existing_columns:
                    connection.execute(
                        text(f'ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}')
                    )


def initialize_database():
    global database_initialized

    if database_initialized:
        return

    db.create_all()
    ensure_database_schema()
    create_admin()
    database_initialized = True

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- Role decorators ---
def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if current_user.role != 'admin':
            flash('Admin access required.', 'error')
            return redirect(url_for('member_dashboard'))
        return f(*args, **kwargs)
    return decorated

# ===================== AUTH =====================

@app.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('member_dashboard'))
    return redirect(url_for('login_selection'))

@app.route('/login-selection')
def login_selection():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('member_dashboard'))
    return render_template('login_selection.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            full_name = request.form.get('full_name', '').strip()
            email = request.form.get('email', '').strip()
            phone = request.form.get('phone', '').strip()
            password = request.form.get('password', '')
            confirm_password = request.form.get('confirm_password', '')
            
            # Validate inputs
            if not full_name or not email or not password:
                flash('All required fields must be filled.', 'error')
                return redirect(url_for('register'))
            
            if not User.validate_email(email):
                flash('Invalid email format.', 'error')
                return redirect(url_for('register'))
            
            if phone and not User.validate_phone(phone):
                flash('Invalid phone number format.', 'error')
                return redirect(url_for('register'))
            
            if len(password) < 6:
                flash('Password must be at least 6 characters long.', 'error')
                return redirect(url_for('register'))
            
            if password != confirm_password:
                flash('Passwords do not match.', 'error')
                return redirect(url_for('register'))

            if User.query.filter_by(email=email).first():
                flash('Email already registered.', 'error')
                return redirect(url_for('register'))

            user = User(
                full_name=full_name,
                email=email,
                phone=phone,
                password=generate_password_hash(password),
                role='member'
            )
            db.session.add(user)
            db.session.commit()
            logger.info(f"New member registered: {email}")
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {str(e)}")
            flash('An error occurred during registration.', 'error')
            return redirect(url_for('register'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('member_dashboard'))
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        # Block admin accounts from member login
        if user and user.role == 'admin':
            flash('Admin accounts cannot use member login. Please use Admin Login.', 'error')
            return redirect(url_for('login'))
        
        if user and check_password_hash(user.password, password) and user.is_active:
            login_user(user)
            return redirect(url_for('member_dashboard'))
        flash('Invalid credentials or account disabled.', 'error')
    return render_template('login.html')

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        # If a member is logged in, logout first
        logout_user()
        flash('Please log in with your admin account.', 'info')
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        # Only allow admin accounts
        if user and user.role != 'admin':
            flash('Only administrators can access this portal. Use Member Login instead.', 'error')
            return redirect(url_for('admin_login'))
        
        if user and check_password_hash(user.password, password) and user.is_active:
            login_user(user)
            return redirect(url_for('admin_dashboard'))
        flash('Invalid admin credentials or account disabled.', 'error')
    return render_template('admin_login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login_selection'))

# ===================== MEMBER PAGES =====================

@app.route('/dashboard')
@login_required
def member_dashboard():
    if current_user.role == 'admin':
        return redirect(url_for('admin_dashboard'))
    my_donations = Donation.query.filter_by(member_id=current_user.id).order_by(Donation.donation_date.desc()).limit(5).all()
    upcoming_events = Event.query.filter(Event.event_date >= datetime.now()).order_by(Event.event_date).limit(5).all()
    my_visits = PastoralVisit.query.filter_by(member_id=current_user.id).order_by(PastoralVisit.visit_date.desc()).limit(3).all()
    total_donated = db.session.query(db.func.sum(Donation.amount)).filter_by(member_id=current_user.id).scalar() or 0
    return render_template('member_dashboard.html',
                           my_donations=my_donations,
                           upcoming_events=upcoming_events,
                           my_visits=my_visits,
                           total_donated=total_donated)

@app.route('/pastoral-visits')
@login_required
def pastoral_visits():
    if current_user.role in ['admin', 'pastor']:
        visits = PastoralVisit.query.order_by(PastoralVisit.visit_date.desc()).all()
    else:
        visits = PastoralVisit.query.filter_by(member_id=current_user.id).order_by(PastoralVisit.visit_date.desc()).all()
    pastors = User.query.filter(User.role.in_(['pastor', 'admin'])).all()
    members = User.query.filter_by(role='member').all()
    return render_template('pastoral_visits.html', visits=visits, pastors=pastors, members=members)

@app.route('/pastoral-visits/add', methods=['POST'])
@login_required
def add_pastoral_visit():
    if current_user.role not in ['admin', 'pastor']:
        flash('Only admins and pastors can schedule visits.', 'error')
        return redirect(url_for('pastoral_visits'))
    
    try:
        member_id = int(request.form.get('member_id', 0))
        pastor_id = int(request.form.get('pastor_id', 0))
        visit_date = datetime.strptime(request.form['visit_date'], '%Y-%m-%dT%H:%M')
        
        # Validate visit date is not in the past
        if visit_date < datetime.now():
            flash('Visit date cannot be in the past.', 'error')
            return redirect(url_for('pastoral_visits'))
        
        # Validate member_id exists
        member = User.query.get(member_id)
        if not member:
            flash('Invalid member selected.', 'error')
            return redirect(url_for('pastoral_visits'))
        
        # Validate pastor_id exists and is admin or pastor
        pastor = User.query.get(pastor_id)
        if not pastor or pastor.role not in ['admin', 'pastor']:
            flash('Invalid pastor selected.', 'error')
            return redirect(url_for('pastoral_visits'))
        
        # Prevent self-visits
        if member_id == pastor_id:
            flash('A member cannot be visited by themselves.', 'error')
            return redirect(url_for('pastoral_visits'))
        
        purpose = request.form.get('purpose', '').strip()
        if not purpose:
            flash('Visit purpose is required.', 'error')
            return redirect(url_for('pastoral_visits'))
        
        visit = PastoralVisit(
            member_id=member_id,
            pastor_id=pastor_id,
            visit_date=visit_date,
            purpose=purpose,
            notes=request.form.get('notes', '').strip(),
            status='scheduled'
        )
        db.session.add(visit)
        db.session.commit()
        flash('Visit scheduled successfully!', 'success')
    except (ValueError, KeyError) as e:
        logger.error(f"Invalid form data in pastoral visit: {str(e)}")
        flash('Invalid form data. Please try again.', 'error')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error scheduling visit: {str(e)}")
        flash('An error occurred while scheduling the visit.', 'error')
    return redirect(url_for('pastoral_visits'))

@app.route('/pastoral-visits/update-status/<int:visit_id>', methods=['POST'])
@login_required
def update_visit_status(visit_id):
    visit = PastoralVisit.query.get_or_404(visit_id)
    visit.status = request.form['status']
    db.session.commit()
    flash('Visit status updated.', 'success')
    return redirect(url_for('pastoral_visits'))

@app.route('/pastoral-visits/delete/<int:visit_id>', methods=['POST'])
@login_required
def delete_pastoral_visit(visit_id):
    visit = PastoralVisit.query.get_or_404(visit_id)
    # Only admin, pastor who scheduled it, or the member can delete
    if current_user.role not in ['admin', 'pastor'] and current_user.id != visit.member_id:
        flash('You do not have permission to delete this visit.', 'error')
        return redirect(url_for('pastoral_visits'))
    member_name = visit.member.full_name
    db.session.delete(visit)
    db.session.commit()
    flash(f'Pastoral visit for {member_name} has been deleted.', 'success')
    return redirect(url_for('pastoral_visits'))

@app.route('/events')
@login_required
def events_calendar():
    events = Event.query.order_by(Event.event_date).all()
    events_json = [{
        'id': e.id, 'title': e.title,
        'date': e.event_date.strftime('%Y-%m-%d'),
        'time': e.event_date.strftime('%H:%M'),
        'type': e.event_type, 'location': e.location or ''
    } for e in events]
    return render_template('events_calendar.html', events=events, events_json=jsonify(events_json).get_json())

@app.route('/events/add', methods=['POST'])
@login_required
def add_event():
    if current_user.role not in ['admin', 'pastor']:
        flash('Only admins and pastors can add events.', 'error')
        return redirect(url_for('events_calendar'))
    
    try:
        title = request.form.get('title', '').strip()
        if not title:
            flash('Event title is required.', 'error')
            return redirect(url_for('events_calendar'))
        
        event_date = datetime.strptime(request.form['event_date'], '%Y-%m-%dT%H:%M')
        
        # Validate event date is not in the past
        if event_date < datetime.now():
            flash('Event date cannot be in the past.', 'error')
            return redirect(url_for('events_calendar'))
        
        event_type = request.form.get('event_type', '').strip()
        if not event_type:
            flash('Event type is required.', 'error')
            return redirect(url_for('events_calendar'))
        
        event = Event(
            title=title,
            description=request.form.get('description', '').strip(),
            event_date=event_date,
            event_type=event_type,
            location=request.form.get('location', '').strip(),
            created_by=current_user.id
        )
        db.session.add(event)
        db.session.commit()
        flash('Event added!', 'success')
    except ValueError as e:
        logger.error(f"Invalid event data: {str(e)}")
        flash('Invalid date format. Please try again.', 'error')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error adding event: {str(e)}")
        flash('An error occurred while adding the event.', 'error')
    return redirect(url_for('events_calendar'))

@app.route('/events/delete/<int:event_id>', methods=['POST'])
@login_required
@admin_required
def delete_event(event_id):
    event = Event.query.get_or_404(event_id)
    db.session.delete(event)
    db.session.commit()
    flash('Event deleted.', 'success')
    return redirect(url_for('events_calendar'))

@app.route('/donations', methods=['GET', 'POST'])
@login_required
def donations():
    if request.method == 'POST':
        donation = Donation(
            member_id=current_user.id,
            amount=float(request.form['amount']),
            donation_type=request.form['donation_type'],
            description=request.form.get('description', '')
        )
        db.session.add(donation)
        db.session.commit()
        flash('Donation recorded. God bless you!', 'success')
        return redirect(url_for('donations'))

    my_donations = Donation.query.filter_by(member_id=current_user.id).order_by(Donation.donation_date.desc()).all()
    total = sum(d.amount for d in my_donations)
    tithe_total = sum(d.amount for d in my_donations if d.donation_type == 'tithe')
    offering_total = sum(d.amount for d in my_donations if d.donation_type == 'offering')
    return render_template('donations.html', donations=my_donations, total=total,
                           tithe_total=tithe_total, offering_total=offering_total)

@app.route('/youtube-services')
@login_required
def youtube_services():
    return render_template('youtube_services.html')

# ===================== MEMBER PROFILE & SETTINGS =====================

@app.route('/member/profile', methods=['GET', 'POST'])
@login_required
def member_profile():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'update_info':
            try:
                # Update name, email, phone
                new_email = request.form.get('email', '').strip()
                new_phone = request.form.get('phone', '').strip()
                
                # Validate email format
                if not User.validate_email(new_email):
                    flash('Invalid email format.', 'error')
                    return redirect(url_for('member_profile'))
                
                # Validate phone format if provided
                if new_phone and not User.validate_phone(new_phone):
                    flash('Invalid phone number format.', 'error')
                    return redirect(url_for('member_profile'))
                
                # Check if email is already taken by someone else
                if new_email != current_user.email:
                    existing_user = User.query.filter_by(email=new_email).first()
                    if existing_user:
                        flash('Email already in use.', 'error')
                        return redirect(url_for('member_profile'))
                
                current_user.full_name = request.form.get('full_name', '').strip()
                current_user.email = new_email
                current_user.phone = new_phone
                db.session.commit()
                flash('Profile updated successfully!', 'success')
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error updating profile: {str(e)}")
                flash('An error occurred while updating your profile.', 'error')
            return redirect(url_for('member_profile'))
        
        elif action == 'change_password':
            try:
                old_password = request.form.get('old_password', '')
                new_password = request.form.get('new_password', '')
                confirm_password = request.form.get('confirm_password', '')
                
                # Verify old password
                if not check_password_hash(current_user.password, old_password):
                    flash('Old password is incorrect.', 'error')
                    return redirect(url_for('member_profile'))
                
                # Check if passwords match
                if new_password != confirm_password:
                    flash('New passwords do not match.', 'error')
                    return redirect(url_for('member_profile'))
                
                # Check password length
                if len(new_password) < 6:
                    flash('Password must be at least 6 characters long.', 'error')
                    return redirect(url_for('member_profile'))
                
                current_user.password = generate_password_hash(new_password)
                db.session.commit()
                flash('Password changed successfully!', 'success')
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error changing password: {str(e)}")
                flash('An error occurred while changing your password.', 'error')
            return redirect(url_for('member_profile'))
        
        elif action == 'delete_account':
            try:
                password = request.form.get('password', '')
                
                # Verify password
                if not check_password_hash(current_user.password, password):
                    flash('Password is incorrect. Account not deleted.', 'error')
                    return redirect(url_for('member_profile'))
                
                user_name = current_user.full_name
                
                # Delete user
                db.session.delete(current_user)
                db.session.commit()
                logger.info(f"Account deleted by user: {user_name}")
                flash(f'Account for {user_name} has been permanently deleted.', 'success')
                return redirect(url_for('login'))
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error deleting account: {str(e)}")
                flash('An error occurred while deleting your account.', 'error')
                return redirect(url_for('member_profile'))
    
    return render_template('member_profile.html')

# ===================== ADMIN PAGES =====================

def build_admin_dashboard_context(member_limit=5):
    member_query = User.query.order_by(User.joined_date.desc())
    recent_members = member_query.limit(member_limit).all() if member_limit else member_query.all()
    total_donations = db.session.query(db.func.sum(Donation.amount)).scalar() or 0
    total_expenses = db.session.query(db.func.sum(Expense.amount)).scalar() or 0

    return {
        'total_members': User.query.filter_by(role='member').count(),
        'total_pastors': User.query.filter_by(role='pastor').count(),
        'total_donations': total_donations,
        'total_expenses': total_expenses,
        'net_balance': total_donations - total_expenses,
        'recent_members': recent_members,
        'recent_donations': Donation.query.order_by(Donation.donation_date.desc()).limit(5).all(),
    }


@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    return render_template('admin_dashboard.html', **build_admin_dashboard_context())

@app.route('/admin/members')
@login_required
@admin_required
def manage_members():
    return render_template(
        'admin_dashboard.html',
        section='members',
        **build_admin_dashboard_context(member_limit=None)
    )

@app.route('/admin/add-pastor', methods=['POST'])
@login_required
@admin_required
def add_pastor():
    user_id = int(request.form['user_id'])
    user = User.query.get_or_404(user_id)
    user.role = 'pastor'
    db.session.commit()
    flash(f'{user.full_name} is now a pastor.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/remove-role/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def remove_role(user_id):
    user = User.query.get_or_404(user_id)
    if user.role == 'admin':
        flash('Cannot change admin role.', 'error')
        return redirect(url_for('admin_dashboard'))
    user.role = 'member'
    db.session.commit()
    flash(f'{user.full_name} role set to member.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/toggle-member/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def toggle_member(user_id):
    user = User.query.get_or_404(user_id)
    if user.role == 'admin':
        flash('Cannot deactivate admin.', 'error')
        return redirect(url_for('admin_dashboard'))
    user.is_active = not user.is_active
    db.session.commit()
    status = 'activated' if user.is_active else 'deactivated'
    flash(f'{user.full_name} has been {status}.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete-member/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def delete_member(user_id):
    try:
        user = User.query.get_or_404(user_id)
        if user.role == 'admin':
            flash('Cannot delete admin account.', 'error')
            return redirect(url_for('admin_dashboard'))
        full_name = user.full_name
        db.session.delete(user)
        db.session.commit()
        logger.info(f"Member deleted by admin: {full_name}")
        flash(f'{full_name} has been permanently deleted.', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting member: {str(e)}")
        flash('An error occurred while deleting the member.', 'error')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete-pastor/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def delete_pastor(user_id):
    user = User.query.get_or_404(user_id)
    if user.role == 'admin':
        flash('Cannot delete admin account.', 'error')
        return redirect(url_for('admin_dashboard'))
    user.role = 'member'
    db.session.commit()
    flash(f'{user.full_name} role has been removed.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/attendance')
@login_required
@admin_required
def attendance():
    records = Attendance.query.order_by(Attendance.date.desc()).all()
    members = User.query.filter(User.role != 'admin').all()
    events = Event.query.order_by(Event.event_date.desc()).all()
    # Summary per member
    from sqlalchemy import func
    summary = db.session.query(User.full_name, func.count(Attendance.id).label('count'))\
        .join(Attendance, User.id == Attendance.member_id).group_by(User.id).all()
    return render_template('attendance.html', records=records, members=members, events=events, summary=summary)

@app.route('/admin/attendance/add', methods=['POST'])
@login_required
@admin_required
def add_attendance():
    try:
        member_ids = request.form.getlist('member_ids')
        if not member_ids:
            flash('Please select at least one member.', 'error')
            return redirect(url_for('attendance'))

        event_id = request.form.get('event_id', type=int)
        if not event_id:
            flash('Please select a service or event.', 'error')
            return redirect(url_for('attendance'))

        event = Event.query.get(event_id)
        if not event:
            flash('Selected event was not found.', 'error')
            return redirect(url_for('attendance'))

        added_count = 0
        skipped_count = 0
        for mid in member_ids:
            try:
                member_id = int(mid)
                # Verify member exists
                if not User.query.get(member_id):
                    continue

                existing_record = Attendance.query.filter_by(
                    member_id=member_id,
                    event_id=event.id
                ).first()
                if existing_record:
                    skipped_count += 1
                    continue

                record = Attendance(
                    member_id=member_id,
                    event_id=event.id,
                    service_name=event.title,
                    date=event.event_date
                )
                db.session.add(record)
                added_count += 1
            except ValueError:
                continue
        
        if added_count == 0:
            if skipped_count:
                flash('Attendance was already recorded for the selected members.', 'info')
            else:
                flash('No valid members were selected.', 'error')
            return redirect(url_for('attendance'))
        
        db.session.commit()
        message = f'Attendance recorded for {added_count} members.'
        if skipped_count:
            message += f' Skipped {skipped_count} duplicate records.'
        flash(message, 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error adding attendance: {str(e)}")
        flash('An error occurred while recording attendance.', 'error')
    return redirect(url_for('attendance'))

@app.route('/admin/finance')
@login_required
@admin_required
def finance():
    all_donations = Donation.query.order_by(Donation.donation_date.desc()).all()
    all_expenses = Expense.query.order_by(Expense.expense_date.desc()).all()
    total_income = db.session.query(db.func.sum(Donation.amount)).scalar() or 0
    total_expenses = db.session.query(db.func.sum(Expense.amount)).scalar() or 0
    tithe = db.session.query(db.func.sum(Donation.amount)).filter_by(donation_type='tithe').scalar() or 0
    offering = db.session.query(db.func.sum(Donation.amount)).filter_by(donation_type='offering').scalar() or 0
    special = db.session.query(db.func.sum(Donation.amount)).filter_by(donation_type='special').scalar() or 0
    return render_template('finance.html',
                           donations=all_donations, expenses=all_expenses,
                           total_income=total_income, total_expenses=total_expenses,
                           net=total_income - total_expenses,
                           tithe=tithe, offering=offering, special=special)

@app.route('/admin/finance/expense/add', methods=['POST'])
@login_required
@admin_required
def add_expense():
    try:
        title = request.form.get('title', '').strip()
        if not title:
            flash('Expense title is required.', 'error')
            return redirect(url_for('finance'))
        
        try:
            amount = float(request.form.get('amount', 0))
            if amount <= 0:
                flash('Amount must be greater than 0.', 'error')
                return redirect(url_for('finance'))
        except ValueError:
            flash('Invalid amount.', 'error')
            return redirect(url_for('finance'))
        
        category = request.form.get('category', '').strip()
        if not category:
            flash('Category is required.', 'error')
            return redirect(url_for('finance'))
        
        expense = Expense(
            title=title,
            amount=amount,
            category=category,
            description=request.form.get('description', '').strip(),
            recorded_by=current_user.id
        )
        db.session.add(expense)
        db.session.commit()
        flash('Expense recorded.', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error adding expense: {str(e)}")
        flash('An error occurred while recording the expense.', 'error')
    return redirect(url_for('finance'))

@app.route('/admin/finance/expense/delete/<int:expense_id>', methods=['POST'])
@login_required
@admin_required
def delete_expense(expense_id):
    expense = Expense.query.get_or_404(expense_id)
    db.session.delete(expense)
    db.session.commit()
    flash('Expense deleted.', 'success')
    return redirect(url_for('finance'))

# ===================== INIT DB =====================

def create_admin():
    admin = User.query.filter_by(email='admin@church.com').first()
    if not admin:
        admin = User(
            full_name='Church Admin',
            email='admin@church.com',
            password=generate_password_hash('admin123'),
            role='admin'
        )
        db.session.add(admin)
        db.session.commit()
        print("Admin created: admin@church.com / admin123")


@app.before_request
def initialize_database_on_request():
    initialize_database()

if __name__ == '__main__':
    with app.app_context():
        initialize_database()
    app.run(debug=True)

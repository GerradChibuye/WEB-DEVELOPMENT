// Auto-dismiss flash messages
document.addEventListener('DOMContentLoaded', function () {
    const flashes = document.querySelectorAll('.flash');
    flashes.forEach(function (flash) {
        setTimeout(function () {
            flash.style.transition = 'opacity 0.5s';
            flash.style.opacity = '0';
            setTimeout(function () { flash.remove(); }, 500);
        }, 4000);
    });
});

// Calendar renderer for events page
function renderCalendar(eventsData) {
    const container = document.getElementById('calendar');
    if (!container) return;

    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Build event map: "YYYY-MM-DD" -> [events]
    const eventMap = {};
    eventsData.forEach(function (e) {
        if (!eventMap[e.date]) eventMap[e.date] = [];
        eventMap[e.date].push(e);
    });

    // Month label
    const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    const monthLabel = document.createElement('div');
    monthLabel.style.cssText = 'grid-column:1/-1;text-align:center;font-family:Playfair Display,serif;font-size:1.1rem;font-weight:700;color:var(--primary-dark);margin-bottom:8px;';
    monthLabel.textContent = monthNames[month] + ' ' + year;
    container.appendChild(monthLabel);

    // Day headers
    dayNames.forEach(function (d) {
        const h = document.createElement('div');
        h.className = 'cal-header';
        h.textContent = d;
        container.appendChild(h);
    });

    // Empty slots before first day
    for (let i = 0; i < firstDay; i++) {
        const empty = document.createElement('div');
        empty.className = 'cal-day empty';
        container.appendChild(empty);
    }

    // Day cells
    for (let d = 1; d <= daysInMonth; d++) {
        const cell = document.createElement('div');
        cell.className = 'cal-day';

        const mm = String(month + 1).padStart(2, '0');
        const dd = String(d).padStart(2, '0');
        const dateStr = year + '-' + mm + '-' + dd;

        if (d === today.getDate()) cell.classList.add('today');
        if (eventMap[dateStr]) cell.classList.add('has-event');

        const num = document.createElement('div');
        num.className = 'cal-day-num';
        num.textContent = d;
        cell.appendChild(num);

        if (eventMap[dateStr]) {
            eventMap[dateStr].forEach(function (ev) {
                const dot = document.createElement('span');
                dot.className = 'cal-event-dot';
                dot.title = ev.title;
                cell.appendChild(dot);
            });
        }

        container.appendChild(cell);
    }
}
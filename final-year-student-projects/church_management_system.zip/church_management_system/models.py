from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
import re

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), default='member')  # 'admin', 'pastor', 'member'
    joined_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    @staticmethod
    def validate_email(email):
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def validate_phone(phone):
        if not phone:
            return True
        pattern = r'^[0-9+\-()\s]{7,20}$'
        return re.match(pattern, phone) is not None

    donations = db.relationship('Donation', backref='member', lazy=True, cascade='all, delete-orphan')
    attendances = db.relationship('Attendance', backref='member', lazy=True, cascade='all, delete-orphan')
    visits_received = db.relationship('PastoralVisit', foreign_keys='PastoralVisit.member_id', backref='member', lazy=True, cascade='all, delete-orphan')
    visits_made = db.relationship('PastoralVisit', foreign_keys='PastoralVisit.pastor_id', backref='pastor', lazy=True)


class PastoralVisit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    pastor_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    visit_date = db.Column(db.DateTime, nullable=False)
    purpose = db.Column(db.String(200), nullable=False)
    notes = db.Column(db.Text)
    status = db.Column(db.String(30), default='scheduled')  # scheduled, completed, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (db.CheckConstraint('member_id != pastor_id', name='check_different_users'),)


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    event_date = db.Column(db.DateTime, nullable=False)
    event_type = db.Column(db.String(50), nullable=False)  # service, meeting, outreach, etc.
    location = db.Column(db.String(150))
    created_by = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='SET NULL'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    attendances = db.relationship('Attendance', backref='event', lazy=True, cascade='all, delete-orphan')


class Donation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    donation_type = db.Column(db.String(50))  # tithe, offering, special
    description = db.Column(db.String(200))
    donation_date = db.Column(db.DateTime, default=datetime.utcnow)


class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id', ondelete='CASCADE'), nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    service_name = db.Column(db.String(100), nullable=False)
    
    __table_args__ = (db.UniqueConstraint('member_id', 'event_id', name='unique_member_event'),)


class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False)  # utilities, salaries, maintenance, etc.
    description = db.Column(db.Text)
    expense_date = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    recorded_by = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='SET NULL'))
    
    __table_args__ = (db.CheckConstraint('amount > 0', name='check_positive_amount'),)
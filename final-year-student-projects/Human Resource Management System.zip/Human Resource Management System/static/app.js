document.querySelectorAll(".graph-fill[data-width]").forEach((bar) => {
    bar.style.width = `${bar.dataset.width}%`;
});

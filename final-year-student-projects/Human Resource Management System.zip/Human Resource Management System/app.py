from flask import Flask, render_template, request, redirect, session
import sqlite3
import calendar
from datetime import datetime

app = Flask(__name__)
app.secret_key = "secret123"

NAVIGATION_LINKS = {
    'admin': [
        {'href': '/admin', 'label': 'Dashboard'},
        {'href': '/add_employee', 'label': 'Employees'},
        {'href': '/manage_leaves', 'label': 'Leaves'},
        {'href': '/manage_applications', 'label': 'Applications'},
        {'href': '/attendance', 'label': 'Attendance'},
        {'href': '/manage_payroll', 'label': 'Payroll'},
        {'href': '/performance', 'label': 'Performance'},
        {'href': '/reports', 'label': 'Reports'},
        {'href': '/profile', 'label': 'Profile'},
        {'href': '/logout', 'label': 'Logout'},
    ],
    'employee': [
        {'href': '/employee', 'label': 'Dashboard'},
        {'href': '/emp_leave_section', 'label': 'Apply Leave'},
        {'href': '/leave_history', 'label': 'Leave History'},
        {'href': '/attendance', 'label': 'Attendance'},
        {'href': '/performance', 'label': 'Performance'},
        {'href': '/profile', 'label': 'Profile'},
        {'href': '/logout', 'label': 'Logout'},
    ],
    'guest': [
        {'href': '/', 'label': 'Login'},
        {'href': '/apply', 'label': 'Apply'},
    ],
}

PAGE_META_BY_ENDPOINT = {
    'admin': {
        'kicker': 'Live HR activity',
        'heading': 'Operational snapshot',
        'copy': 'A quick read on staffing, leave approvals, recruitment, and payroll pressure.',
        'action_href': '/reports',
        'action_label': 'Open Full Reports',
    },
    'add_employee': {
        'kicker': 'Workforce records',
        'heading': 'Employee management hub',
        'copy': 'Add new teammates, update details, and keep your people records organized.',
    },
    'edit_employee': {
        'kicker': 'Record updates',
        'heading': 'Employee details editor',
        'copy': 'Adjust role, pay, reporting, and contact details without leaving the workspace.',
    },
    'employee': {
        'kicker': 'Personal workspace',
        'heading': 'Your day at a glance',
        'copy': 'Keep tabs on attendance, leave, payroll, and performance from one dashboard.',
    },
    'emp_leave_section': {
        'kicker': 'Request time off',
        'heading': 'Plan your leave',
        'copy': 'Submit a leave request with the dates and context your team needs.',
    },
    'leave_history': {
        'kicker': 'Time away',
        'heading': 'Leave timeline',
        'copy': 'Look back at past requests and current approval outcomes in one view.',
    },
    'manage_leaves': {
        'kicker': 'Approval queue',
        'heading': 'Leave decisions',
        'copy': 'Review upcoming absences quickly and keep response times moving.',
    },
    'manage_applications': {
        'kicker': 'Hiring pipeline',
        'heading': 'Application review board',
        'copy': 'Move candidates through the queue and keep hiring decisions visible.',
    },
    'attendance': {
        'kicker': 'Time tracking',
        'heading': 'Attendance overview',
        'copy': 'Monitor clock-ins, clock-outs, and daily presence without leaving this page.',
    },
    'manage_payroll': {
        'kicker': 'Compensation cycle',
        'heading': 'Payroll command center',
        'copy': 'Generate pay runs and review posted payroll records from one workflow.',
    },
    'performance': {
        'kicker': 'Growth tracking',
        'heading': 'Performance snapshot',
        'copy': 'Capture review feedback, scores, and follow-up actions in one place.',
    },
    'reports': {
        'kicker': 'Visual reporting',
        'heading': 'Workforce pulse',
        'copy': 'Compare headcount, leave load, hiring volume, payroll, and review quality at a glance.',
    },
    'profile': {
        'kicker': 'Account settings',
        'heading': 'Profile overview',
        'copy': 'Review your account details and update access information when needed.',
    },
    'apply': {
        'kicker': 'Candidate portal',
        'heading': 'Start your application',
        'copy': 'Share your background and role interest so the HR team can review your fit.',
    },
}

def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            role TEXT
        )
        '''
    )

    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS employees(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            position TEXT,
            salary TEXT,
            department TEXT,
            hire_date TEXT,
            manager TEXT,
            user_id INTEGER
        )
        '''
    )

    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS leaves(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER,
            start_date TEXT,
            end_date TEXT,
            reason TEXT,
            status TEXT DEFAULT 'pending',
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
        '''
    )

    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS applications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            position TEXT,
            resume TEXT,
            status TEXT DEFAULT 'pending'
        )
        '''
    )

    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER,
            date TEXT,
            clock_in TEXT,
            clock_out TEXT,
            status TEXT DEFAULT 'present',
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
        '''
    )

    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS payroll(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER,
            pay_period_start TEXT,
            pay_period_end TEXT,
            gross_pay REAL,
            deductions REAL,
            net_pay REAL,
            status TEXT DEFAULT 'completed',
            created_at TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
        '''
    )

    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS performance_reviews(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER,
            review_date TEXT,
            reviewer TEXT,
            score INTEGER,
            comments TEXT,
            action_items TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
        '''
    )

    try:
        cursor.execute('ALTER TABLE employees ADD COLUMN department TEXT')
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute('ALTER TABLE employees ADD COLUMN hire_date TEXT')
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute('ALTER TABLE employees ADD COLUMN manager TEXT')
    except sqlite3.OperationalError:
        pass

    conn.commit()
    conn.close()


def create_admin():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE username = 'admin'")

    if not cursor.fetchone():
        cursor.execute(
            '''
            INSERT INTO users (username, password, role) VALUES (?, ?, ?)
            '''
            , ('Eliza', 'admin123', 'admin'))

    conn.commit()
    conn.close()


def get_employee_by_user(user_id):
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM employees WHERE user_id = ?', (user_id,))
    employee = cursor.fetchone()
    connection.close()
    return employee


def parse_salary(salary_text):
    try:
        return float(str(salary_text).replace(',', '').strip())
    except Exception:
        return 0.0


def current_month_range():
    today = datetime.now()
    first_day = today.replace(day=1).strftime('%Y-%m-%d')
    last_day = today.replace(day=calendar.monthrange(today.year, today.month)[1]).strftime('%Y-%m-%d')
    return first_day, last_day


def build_chart_metrics(items):
    peak = max((item['value'] for item in items), default=1) or 1
    metrics = []
    for item in items:
        metric = dict(item)
        metric['percentage'] = max(8, round((item['value'] / peak) * 100)) if item['value'] else 0
        metrics.append(metric)
    return metrics


def get_navigation_links(role):
    return NAVIGATION_LINKS.get(role or 'guest', NAVIGATION_LINKS['guest'])


@app.context_processor
def inject_template_context():
    role = session.get('role')
    endpoint = request.endpoint
    page_meta = PAGE_META_BY_ENDPOINT.get(endpoint, {})
    return {
        'nav_links': get_navigation_links(role),
        'page_meta': page_meta,
    }


@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = cursor.fetchone()
        connection.close()

        if user:
            session['user_id'] = user[0]
            session['role'] = user[3]

            if user[3] == 'admin':
                return redirect('/admin')
            return redirect('/employee')

        return "Invalid Login"

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')


@app.route('/apply', methods=['GET', 'POST'])
def apply():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        position = request.form['position']
        resume = request.form['resume']

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()
        cursor.execute(
            '''
            INSERT INTO applications (name, email, position, resume)
            VALUES (?, ?, ?, ?)
            ''',
            (name, email, position, resume)
        )
        connection.commit()
        connection.close()

        return redirect('/')

    return render_template('apply.html')


@app.route('/admin')
def admin():
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    cursor.execute('SELECT COUNT(*) FROM employees')
    employee_count = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM leaves WHERE status = "pending"')
    pending_leaves = cursor.fetchone()[0]

    today = datetime.now().strftime('%Y-%m-%d')
    cursor.execute('SELECT COUNT(*) FROM leaves WHERE status = "approved" AND ? BETWEEN start_date AND end_date', (today,))
    on_leave_count = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM applications WHERE status = "pending"')
    pending_applications = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM payroll WHERE status = "pending"')
    pending_payroll = cursor.fetchone()[0]

    connection.close()

    admin_metrics = build_chart_metrics([
        {
            'title': 'Total Employees',
            'value': employee_count,
            'description': 'Active workforce records in the system.',
            'href': '/add_employee',
            'accent': 'teal'
        },
        {
            'title': 'Pending Leave Requests',
            'value': pending_leaves,
            'description': 'Requests that still need an approval decision.',
            'href': '/manage_leaves',
            'accent': 'amber'
        },
        {
            'title': 'Employees on Leave',
            'value': on_leave_count,
            'description': 'People currently away today.',
            'href': '/reports',
            'accent': 'violet'
        },
        {
            'title': 'Pending Applications',
            'value': pending_applications,
            'description': 'Candidates waiting in the hiring queue.',
            'href': '/manage_applications',
            'accent': 'coral'
        },
        {
            'title': 'Payroll Pending',
            'value': pending_payroll,
            'description': 'Payroll items not yet finalized.',
            'href': '/manage_payroll',
            'accent': 'blue'
        }
    ])

    return render_template('admin.html',
                           employee_count=employee_count,
                           pending_leaves=pending_leaves,
                           on_leave_count=on_leave_count,
                           pending_applications=pending_applications,
                           pending_payroll=pending_payroll,
                           admin_metrics=admin_metrics)


@app.route('/add_employee', methods=['GET', 'POST'])
def add_employee():
    if session.get('role') != 'admin':
        return redirect('/')

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        position = request.form['position']
        salary = request.form['salary']
        department = request.form.get('department', '')
        hire_date = request.form.get('hire_date', '')
        manager = request.form.get('manager', '')

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        username = email
        password = '1234'

        cursor.execute(
            '''
            INSERT INTO users (username, password, role)
            VALUES (?, ?, ?)
            ''',
            (username, password, 'employee')
        )

        user_id = cursor.lastrowid

        cursor.execute(
            '''
            INSERT INTO employees(name, email, position, salary, department, hire_date, manager, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (name, email, position, salary, department, hire_date, manager, user_id)
        )

        connection.commit()
        connection.close()

        return redirect('/add_employee')

    search_query = request.args.get('search', '')
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    if search_query:
        cursor.execute('SELECT * FROM employees WHERE name LIKE ? OR email LIKE ? OR position LIKE ? OR department LIKE ?',
                       ('%' + search_query + '%', '%' + search_query + '%', '%' + search_query + '%', '%' + search_query + '%'))
    else:
        cursor.execute('SELECT * FROM employees')

    employees = cursor.fetchall()
    connection.close()

    return render_template('add_employee.html', employees=employees, search_query=search_query)


@app.route('/delete_employee/<int:id>')
def delete_employee(id):
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    cursor.execute('DELETE FROM employees WHERE id = ?', (id,))
    connection.commit()
    connection.close()

    return redirect('/add_employee')


@app.route('/edit_employee/<int:id>', methods=['GET', 'POST'])
def edit_employee(id):
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        position = request.form['position']
        salary = request.form['salary']
        department = request.form.get('department', '')
        hire_date = request.form.get('hire_date', '')
        manager = request.form.get('manager', '')

        cursor.execute('UPDATE employees SET name = ?, email = ?, position = ?, salary = ?, department = ?, hire_date = ?, manager = ? WHERE id = ?',
                      (name, email, position, salary, department, hire_date, manager, id))
        connection.commit()
        connection.close()

        return redirect('/add_employee')

    cursor.execute('SELECT * FROM employees WHERE id = ?', (id,))
    employee = cursor.fetchone()
    connection.close()

    return render_template('edit_employee.html', employee=employee)


@app.route('/employee')
def employee():
    if session.get('role') != 'employee':
        return redirect('/')

    employee = get_employee_by_user(session.get('user_id'))
    if not employee:
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    cursor.execute('SELECT COUNT(*) FROM leaves WHERE employee_id = ?', (employee[0],))
    leave_count = cursor.fetchone()[0]

    cursor.execute('SELECT date, clock_in, clock_out, status FROM attendance WHERE employee_id = ? ORDER BY date DESC LIMIT 7', (employee[0],))
    attendance_history = cursor.fetchall()

    cursor.execute('SELECT pay_period_start, pay_period_end, gross_pay, deductions, net_pay, status FROM payroll WHERE employee_id = ? ORDER BY id DESC LIMIT 5', (employee[0],))
    payroll_history = cursor.fetchall()

    cursor.execute('SELECT review_date, reviewer, score, comments, action_items FROM performance_reviews WHERE employee_id = ? ORDER BY id DESC LIMIT 5', (employee[0],))
    reviews = cursor.fetchall()

    connection.close()

    return render_template('employee.html', employee=employee, leave_count=leave_count,
                           attendance_history=attendance_history, payroll_history=payroll_history, reviews=reviews)


@app.route('/emp_leave_section')
def emp_leave_section():
    if session.get('role') != 'employee':
        return redirect('/')

    return render_template('emp_leave_section.html')


@app.route('/leave_history')
def leave_history():
    if session.get('role') != 'employee':
        return redirect('/')

    employee = get_employee_by_user(session.get('user_id'))
    if not employee:
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('SELECT start_date, end_date, reason, status FROM leaves WHERE employee_id = ? ORDER BY id DESC', (employee[0],))
    leaves = cursor.fetchall()
    connection.close()

    return render_template('leave_history.html', leaves=leaves)


@app.route('/request_leave', methods=['POST'])
def request_leave():
    if session.get('role') != 'employee':
        return redirect('/')

    user_id = session.get('user_id')
    start_date = request.form['start_date']
    end_date = request.form['end_date']
    reason = request.form['reason']

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('SELECT id FROM employees WHERE user_id = ?', (user_id,))
    employee = cursor.fetchone()

    if employee:
        cursor.execute('INSERT INTO leaves (employee_id, start_date, end_date, reason) VALUES (?, ?, ?, ?)',
                      (employee[0], start_date, end_date, reason))
        connection.commit()

    connection.close()
    return redirect('/emp_leave_section')


@app.route('/manage_leaves')
def manage_leaves():
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('''
        SELECT l.id, e.name, l.start_date, l.end_date, l.reason, l.status
        FROM leaves l
        JOIN employees e ON l.employee_id = e.id
        ORDER BY l.id DESC
    ''')
    leaves = cursor.fetchall()
    connection.close()

    return render_template('manage_leaves.html', leaves=leaves)


@app.route('/approve_leave/<int:id>')
def approve_leave(id):
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('UPDATE leaves SET status = "approved" WHERE id = ?', (id,))
    connection.commit()
    connection.close()
    return redirect('/manage_leaves')


@app.route('/reject_leave/<int:id>')
def reject_leave(id):
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('UPDATE leaves SET status = "rejected" WHERE id = ?', (id,))
    connection.commit()
    connection.close()
    return redirect('/manage_leaves')


@app.route('/manage_applications')
def manage_applications():
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM applications ORDER BY id DESC')
    applications = cursor.fetchall()
    connection.close()

    return render_template('manage_applications.html', applications=applications)


@app.route('/accept_application/<int:id>')
def accept_application(id):
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('UPDATE applications SET status = "accepted" WHERE id = ?', (id,))
    connection.commit()
    connection.close()
    return redirect('/manage_applications')


@app.route('/decline_application/<int:id>')
def decline_application(id):
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute('UPDATE applications SET status = "declined" WHERE id = ?', (id,))
    connection.commit()
    connection.close()
    return redirect('/manage_applications')


@app.route('/attendance', methods=['GET', 'POST'])
def attendance():
    role = session.get('role')
    if role not in ['employee', 'admin']:
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    if request.method == 'POST' and role == 'employee':
        action = request.form['action']
        employee = get_employee_by_user(session.get('user_id'))
        if employee:
            current_date = datetime.now().strftime('%Y-%m-%d')
            current_time = datetime.now().strftime('%H:%M:%S')
            cursor.execute('SELECT id FROM attendance WHERE employee_id = ? AND date = ?', (employee[0], current_date))
            record = cursor.fetchone()
            if action == 'clock_in':
                if record:
                    cursor.execute('UPDATE attendance SET clock_in = ?, status = "present" WHERE id = ?', (current_time, record[0]))
                else:
                    cursor.execute('INSERT INTO attendance (employee_id, date, clock_in, status) VALUES (?, ?, ?, ?)',
                                   (employee[0], current_date, current_time, 'present'))
            elif action == 'clock_out' and record:
                cursor.execute('UPDATE attendance SET clock_out = ? WHERE id = ?', (current_time, record[0]))
            connection.commit()

    if role == 'admin':
        cursor.execute('''
            SELECT a.date, e.name, a.clock_in, a.clock_out, a.status
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            ORDER BY a.date DESC
        ''')
        attendance_records = cursor.fetchall()
    else:
        employee = get_employee_by_user(session.get('user_id'))
        attendance_records = []
        if employee:
            cursor.execute('SELECT date, clock_in, clock_out, status FROM attendance WHERE employee_id = ? ORDER BY date DESC LIMIT 30', (employee[0],))
            attendance_records = cursor.fetchall()

    connection.close()
    return render_template('attendance.html', attendance_records=attendance_records, role=role)


@app.route('/manage_payroll', methods=['GET', 'POST'])
def manage_payroll():
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    if request.method == 'POST':
        period_start = request.form['period_start']
        period_end = request.form['period_end']
        cursor.execute('SELECT id, salary FROM employees')
        employees = cursor.fetchall()
        for employee_id, salary in employees:
            gross = parse_salary(salary)
            deductions = round(gross * 0.10, 2)
            net_pay = round(gross - deductions, 2)
            created_at = datetime.now().strftime('%Y-%m-%d')
            cursor.execute('''
                INSERT INTO payroll (employee_id, pay_period_start, pay_period_end, gross_pay, deductions, net_pay, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (employee_id, period_start, period_end, gross, deductions, net_pay, 'completed', created_at))
        connection.commit()

    cursor.execute('''
        SELECT p.id, e.name, p.pay_period_start, p.pay_period_end, p.gross_pay, p.deductions, p.net_pay, p.status, p.created_at
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id
        ORDER BY p.id DESC
    ''')
    payroll_records = cursor.fetchall()
    connection.close()

    return render_template('manage_payroll.html', payroll_records=payroll_records)


@app.route('/performance', methods=['GET', 'POST'])
def performance():
    role = session.get('role')
    if role not in ['admin', 'employee']:
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    if role == 'admin' and request.method == 'POST':
        employee_id = request.form['employee_id']
        reviewer = request.form['reviewer']
        score = int(request.form['score'])
        comments = request.form['comments']
        action_items = request.form['action_items']
        review_date = datetime.now().strftime('%Y-%m-%d')
        cursor.execute('''
            INSERT INTO performance_reviews (employee_id, review_date, reviewer, score, comments, action_items)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (employee_id, review_date, reviewer, score, comments, action_items))
        connection.commit()

    if role == 'admin':
        cursor.execute('''
            SELECT pr.id, e.name, pr.review_date, pr.reviewer, pr.score, pr.comments, pr.action_items
            FROM performance_reviews pr
            JOIN employees e ON pr.employee_id = e.id
            ORDER BY pr.id DESC
        ''')
        reviews = cursor.fetchall()
        cursor.execute('SELECT id, name FROM employees ORDER BY name')
        employees = cursor.fetchall()
        connection.close()
        return render_template('performance.html', role=role, reviews=reviews, employees=employees)

    employee = get_employee_by_user(session.get('user_id'))
    reviews = []
    if employee:
        cursor.execute('''
            SELECT review_date, reviewer, score, comments, action_items
            FROM performance_reviews
            WHERE employee_id = ?
            ORDER BY id DESC
        ''', (employee[0],))
        reviews = cursor.fetchall()
    connection.close()
    return render_template('performance.html', role=role, reviews=reviews)


@app.route('/reports')
def reports():
    if session.get('role') != 'admin':
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    cursor.execute('SELECT COUNT(*) FROM employees')
    total_employees = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM leaves WHERE status = "pending"')
    pending_leaves = cursor.fetchone()[0]

    today = datetime.now().strftime('%Y-%m-%d')
    cursor.execute('SELECT COUNT(*) FROM leaves WHERE status = "approved" AND ? BETWEEN start_date AND end_date', (today,))
    on_leave_count = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM applications')
    total_applications = cursor.fetchone()[0]

    cursor.execute('SELECT SUM(net_pay) FROM payroll')
    total_payroll = cursor.fetchone()[0] or 0

    cursor.execute('SELECT AVG(score) FROM performance_reviews')
    average_score = cursor.fetchone()[0] or 0

    connection.close()

    report_overview = build_chart_metrics([
        {
            'title': 'Employees',
            'value': total_employees,
            'description': 'Current team size.',
            'accent': 'teal'
        },
        {
            'title': 'Pending Leaves',
            'value': pending_leaves,
            'description': 'Awaiting approval.',
            'accent': 'amber'
        },
        {
            'title': 'On Leave Today',
            'value': on_leave_count,
            'description': 'Away right now.',
            'accent': 'violet'
        },
        {
            'title': 'Applications',
            'value': total_applications,
            'description': 'Candidates in pipeline.',
            'accent': 'coral'
        }
    ])

    payroll_display = f"ZMW {total_payroll:,.2f}"
    payroll_progress = 100 if total_payroll > 0 else 0
    review_progress = max(0, min(100, round((average_score / 10) * 100)))

    return render_template('reports.html',
                           total_employees=total_employees,
                           pending_leaves=pending_leaves,
                           on_leave_count=on_leave_count,
                           total_applications=total_applications,
                           total_payroll=round(total_payroll, 2),
                           average_score=round(average_score, 2),
                           report_overview=report_overview,
                           payroll_display=payroll_display,
                           payroll_progress=payroll_progress,
                           review_progress=review_progress)


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    user_id = session.get('user_id')
    if not user_id:
        return redirect('/')

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()

    if request.method == 'POST':
        username = request.form['username']
        password = request.form.get('password')
        if password:
            cursor.execute('UPDATE users SET username = ?, password = ? WHERE id = ?', (username, password, user_id))
        else:
            cursor.execute('UPDATE users SET username = ? WHERE id = ?', (username, user_id))
        connection.commit()

    cursor.execute('SELECT username, role FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    connection.close()

    back_url = '/admin' if user and user[1] == 'admin' else '/employee'
    return render_template('profile.html', user=user, back_url=back_url)


if __name__ == '__main__':
    init_db()
    create_admin()
    app.run(debug=True)
    

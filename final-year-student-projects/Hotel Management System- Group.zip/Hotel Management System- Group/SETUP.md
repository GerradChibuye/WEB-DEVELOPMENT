# Hotel Manager — Setup Guide

## Requirements
- Python 3.8+  (no MySQL, no extra database software needed)

## 1. Install dependencies
```bash
pip install flask flask-cors
```

## 2. Run the server
```bash
python app.py
```

## 3. Open in browser
Go to: http://localhost:5000

The database file `hotel.db` is created automatically on first run.

## Default admin login
- Username: `admin`
- Password: `admin`

## Roles
- **Admin** — full access: manage rooms, bookings, guests, dashboard
- **Guest** — browse rooms, make bookings, cancel bookings

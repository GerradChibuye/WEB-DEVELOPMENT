from flask import Flask, request, jsonify, session
from flask_cors import CORS
from database import get_db, init_db

app = Flask(__name__, static_folder=".", static_url_path="")
app.secret_key = "hotel_secret_key_2026"
CORS(app, supports_credentials=True)

init_db()

# ── DB helpers ────────────────────────────────────────────────────────────────

def query(sql, params=(), fetch="all"):
    """Run a SELECT, return list-of-dicts or a single dict."""
    # MySQL uses %s placeholders instead of ?
    sql  = sql.replace("?", "%s")
    conn = get_db()
    cur  = conn.cursor(dictionary=True)
    cur.execute(sql, params)
    rows = cur.fetchall() if fetch == "all" else cur.fetchone()
    conn.close()
    return rows if rows else (None if fetch == "one" else [])

def execute(sql, params=()):
    """Run INSERT/UPDATE/DELETE, return lastrowid."""
    sql  = sql.replace("?", "%s")
    conn = get_db()
    cur  = conn.cursor()
    cur.execute(sql, params)
    conn.commit()
    lid = cur.lastrowid
    conn.close()
    return lid

def log_activity(message, color="blue"):
    execute("INSERT INTO activity_log (message, color) VALUES (?,?)", (message, color))

# ── auth ──────────────────────────────────────────────────────────────────────

@app.route("/api/signup", methods=["POST"])
def signup():
    d         = request.get_json(force=True) or {}
    username  = (d.get("username")  or "").strip()
    password  = (d.get("password")  or "").strip()
    role      = d.get("role", "customer")
    full_name = (d.get("full_name") or "").strip()
    email     = (d.get("email")     or "").strip()
    phone     = (d.get("phone")     or "").strip()

    if role not in ("admin", "customer"):
        role = "customer"
    if not username or not password:
        return jsonify({"ok": False, "error": "Username and password are required"}), 400
    if len(password) < 4:
        return jsonify({"ok": False, "error": "Password must be at least 4 characters"}), 400
    if query("SELECT id FROM users WHERE username=?", (username,), fetch="one"):
        return jsonify({"ok": False, "error": "Username already taken"}), 409

    execute(
        "INSERT INTO users (username,password,role,full_name,email,phone) VALUES (?,?,?,?,?,?)",
        (username, password, role, full_name, email, phone)
    )
    return jsonify({"ok": True})

@app.route("/api/login", methods=["POST"])
def login():
    d        = request.get_json(force=True) or {}
    username = (d.get("username") or "").strip()
    password = (d.get("password") or "").strip()

    if not username or not password:
        return jsonify({"ok": False, "error": "Username and password are required"}), 400

    user = query(
        "SELECT id,username,role,full_name,email,phone FROM users WHERE username=? AND password=?",
        (username, password), fetch="one"
    )
    if user:
        session["user"]    = user["username"]
        session["role"]    = user["role"]
        session["user_id"] = user["id"]
        return jsonify({
            "ok":        True,
            "id":        user["id"],
            "username":  user["username"],
            "role":      user["role"],
            "full_name": user["full_name"] or user["username"]
        })
    return jsonify({"ok": False, "error": "Invalid username or password"}), 401

@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"ok": True})

# ── dashboard ─────────────────────────────────────────────────────────────────

@app.route("/api/dashboard")
def dashboard():
    total_rooms     = query("SELECT COUNT(*) AS n FROM rooms",                          fetch="one")["n"]
    available_rooms = query("SELECT COUNT(*) AS n FROM rooms WHERE status='Available'", fetch="one")["n"]
    booked_rooms    = query("SELECT COUNT(*) AS n FROM rooms WHERE status='Booked'",    fetch="one")["n"]
    total_guests    = query("SELECT COUNT(*) AS n FROM guests",                         fetch="one")["n"]

    occupancy = []
    for t in ["Single", "Double", "Deluxe"]:
        total  = query("SELECT COUNT(*) AS n FROM rooms WHERE room_type=?", (t,), fetch="one")["n"]
        booked = query("SELECT COUNT(*) AS n FROM rooms WHERE room_type=? AND status='Booked'", (t,), fetch="one")["n"]
        occupancy.append({"type": t, "booked": booked, "total": total})

    activities = query(
        "SELECT message, color, created_at FROM activity_log ORDER BY id DESC LIMIT 10"
    ) or []

    pending_approvals = query("SELECT COUNT(*) AS n FROM guest_approvals WHERE status='Pending'", fetch="one")["n"]

    return jsonify({
        "total_rooms":     total_rooms,
        "available_rooms": available_rooms,
        "booked_rooms":    booked_rooms,
        "total_guests":    total_guests,
        "occupancy":       occupancy,
        "activities":      activities,
        "pending_approvals": pending_approvals,
    })

# ── rooms ─────────────────────────────────────────────────────────────────────

@app.route("/api/rooms/available")
def available_rooms():
    return jsonify(query("SELECT * FROM rooms WHERE status='Available' ORDER BY room_number") or [])

@app.route("/api/rooms", methods=["GET"])
def get_rooms():
    return jsonify(query("SELECT * FROM rooms ORDER BY room_number") or [])

@app.route("/api/rooms", methods=["POST"])
def add_room():
    d     = request.get_json(force=True) or {}
    rn    = (d.get("room_number")    or "").strip()
    rtype = (d.get("room_type")      or "").strip()
    floor = (d.get("floor")          or "").strip()
    desc  = (d.get("description")    or "").strip()
    price = d.get("price_per_night")

    if not rn or not rtype or not floor or price is None:
        return jsonify({"error": "All fields are required"}), 400
    try:
        price = float(price)
        if price <= 0:
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({"error": "Price must be a positive number"}), 400

    if query("SELECT id FROM rooms WHERE room_number=?", (rn,), fetch="one"):
        return jsonify({"error": f"Room {rn} already exists"}), 409

    execute(
        "INSERT INTO rooms (room_number,room_type,floor,price_per_night,description) VALUES (?,?,?,?,?)",
        (rn, rtype, floor, price, desc)
    )
    log_activity(f"Room {rn} added", "blue")
    return jsonify({"ok": True})

@app.route("/api/rooms/<int:room_id>", methods=["DELETE"])
def delete_room(room_id):
    room = query("SELECT * FROM rooms WHERE id=?", (room_id,), fetch="one")
    if not room:
        return jsonify({"error": "Room not found"}), 404
    # don't delete a booked room
    if room["status"] == "Booked":
        return jsonify({"error": "Cannot delete a room that is currently booked"}), 409
    execute("DELETE FROM rooms WHERE id=?", (room_id,))
    log_activity(f"Room {room['room_number']} deleted", "red")
    return jsonify({"ok": True})

@app.route("/api/rooms/<int:room_id>/status", methods=["PATCH"])
def update_room_status(room_id):
    d      = request.get_json(force=True) or {}
    status = d.get("status", "")
    if status not in ("Available", "Booked", "Maintenance"):
        return jsonify({"error": "Invalid status"}), 400
    execute("UPDATE rooms SET status=? WHERE id=?", (status, room_id))
    return jsonify({"ok": True})

# ── guests ────────────────────────────────────────────────────────────────────

@app.route("/api/guests", methods=["GET"])
def get_guests():
    rows = query("""
        SELECT g.id, g.name, g.email, g.phone,
               b.id AS booking_id, r.room_number, r.room_type,
               b.check_in, b.check_out, b.status AS booking_status
        FROM guests g
        LEFT JOIN bookings b ON b.id = (
            SELECT id FROM bookings WHERE guest_id=g.id ORDER BY id DESC LIMIT 1
        )
        LEFT JOIN rooms r ON r.id = b.room_id
        ORDER BY g.id DESC
    """) or []
    return jsonify(rows)

@app.route("/api/guests", methods=["POST"])
def add_guest():
    d    = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Guest name is required"}), 400
    gid = execute(
        "INSERT INTO guests (name,email,phone) VALUES (?,?,?)",
        (name, d.get("email",""), d.get("phone",""))
    )
    log_activity(f"Guest added — {name}", "purple")
    return jsonify({"ok": True, "guest_id": gid})

@app.route("/api/guests/<int:guest_id>", methods=["DELETE"])
def delete_guest(guest_id):
    guest = query("SELECT * FROM guests WHERE id=?", (guest_id,), fetch="one")
    if not guest:
        return jsonify({"error": "Guest not found"}), 404
    for b in (query("SELECT room_id FROM bookings WHERE guest_id=? AND status='Active'", (guest_id,)) or []):
        execute("UPDATE rooms SET status='Available' WHERE id=?", (b["room_id"],))
    execute("DELETE FROM bookings WHERE guest_id=?", (guest_id,))
    execute("DELETE FROM guests WHERE id=?", (guest_id,))
    log_activity(f"Guest removed — {guest['name']}", "red")
    return jsonify({"ok": True})

# ── bookings ──────────────────────────────────────────────────────────────────

@app.route("/api/bookings", methods=["GET"])
def get_bookings():
    rows = query("""
        SELECT b.id, b.check_in, b.check_out, b.num_guests,
               b.special_requests, b.status,
               g.name AS guest_name, r.room_number, r.room_type, r.price_per_night
        FROM bookings b
        JOIN guests g ON g.id = b.guest_id
        JOIN rooms  r ON r.id = b.room_id
        ORDER BY b.id DESC
    """) or []
    return jsonify(rows)

@app.route("/api/bookings", methods=["POST"])
def create_booking():
    d           = request.get_json(force=True) or {}
    guest_name  = (d.get("guest_name")  or "").strip()
    room_number = (d.get("room_number") or "").strip()
    check_in    = (d.get("check_in")    or "").strip()
    check_out   = (d.get("check_out")   or "").strip()

    if not guest_name or not room_number or not check_in or not check_out:
        return jsonify({"error": "Guest name, room, check-in and check-out are required"}), 400
    if check_out <= check_in:
        return jsonify({"error": "Check-out must be after check-in"}), 400

    room = query("SELECT * FROM rooms WHERE room_number=?", (room_number,), fetch="one")
    if not room:
        return jsonify({"error": "Room not found"}), 404
    if room["status"] == "Booked":
        return jsonify({"error": "Room is already booked"}), 409

    guest = query("SELECT id FROM guests WHERE name=? AND email=?",
                  (guest_name, d.get("email","")), fetch="one")
    guest_id = guest["id"] if guest else execute(
        "INSERT INTO guests (name,email,phone,user_id) VALUES (?,?,?,?)",
        (guest_name, d.get("email",""), d.get("phone",""), d.get("user_id"))
    )

    execute("""
        INSERT INTO bookings (guest_id,room_id,check_in,check_out,num_guests,special_requests,status)
        VALUES (?,?,?,?,?,?,'Pending')
    """, (guest_id, room["id"], check_in, check_out,
          int(d.get("num_guests", 1)), d.get("special_requests","")))

    execute("UPDATE rooms SET status='Booked' WHERE id=?", (room["id"],))
    log_activity(f"New booking — Room {room_number} ({guest_name})", "blue")
    return jsonify({"ok": True})

@app.route("/api/bookings/<int:booking_id>/checkout", methods=["PATCH"])
def checkout(booking_id):
    booking = query("SELECT * FROM bookings WHERE id=?", (booking_id,), fetch="one")
    if not booking:
        return jsonify({"error": "Booking not found"}), 404
    if booking["status"] != "Active":
        return jsonify({"error": "Booking is not active"}), 400
    execute("UPDATE bookings SET status='Checked Out' WHERE id=?", (booking_id,))
    execute("UPDATE rooms SET status='Available' WHERE id=?", (booking["room_id"],))
    guest = query("SELECT name FROM guests WHERE id=?", (booking["guest_id"],), fetch="one")
    room  = query("SELECT room_number FROM rooms WHERE id=?", (booking["room_id"],), fetch="one")
    log_activity(f"Room {room['room_number']} checked out — {guest['name']}", "red")
    return jsonify({"ok": True})

@app.route("/api/bookings/<int:booking_id>", methods=["DELETE"])
def delete_booking(booking_id):
    booking = query("SELECT * FROM bookings WHERE id=?", (booking_id,), fetch="one")
    if not booking:
        return jsonify({"error": "Booking not found"}), 404
    execute("UPDATE bookings SET status='Cancelled' WHERE id=?", (booking_id,))
    execute("UPDATE rooms SET status='Available' WHERE id=?", (booking["room_id"],))
    guest = query("SELECT name FROM guests WHERE id=?", (booking["guest_id"],), fetch="one")
    room  = query("SELECT room_number FROM rooms WHERE id=?", (booking["room_id"],), fetch="one")
    log_activity(f"Booking cancelled — Room {room['room_number']} ({guest['name']})", "red")
    return jsonify({"ok": True})

# ── customer endpoints ────────────────────────────────────────────────────────

@app.route("/api/customer/bookings")
def customer_bookings():
    user_id = request.args.get("user_id")
    if not user_id:
        return jsonify([])
    rows = query("""
        SELECT b.id, b.check_in, b.check_out, b.num_guests,
               b.special_requests, b.status,
               r.room_number, r.room_type, r.price_per_night, r.floor
        FROM bookings b
        JOIN guests g ON g.id = b.guest_id
        JOIN rooms  r ON r.id = b.room_id
        WHERE g.user_id = ?
        ORDER BY b.id DESC
    """, (user_id,)) or []
    return jsonify(rows)

@app.route("/api/customer/book", methods=["POST"])
def customer_book():
    d       = request.get_json(force=True) or {}
    user_id = d.get("user_id")
    if not user_id:
        return jsonify({"error": "Not authenticated"}), 401

    user = query("SELECT * FROM users WHERE id=?", (user_id,), fetch="one")
    if not user:
        return jsonify({"error": "User not found"}), 404

    room_number = (d.get("room_number") or "").strip()
    check_in    = (d.get("check_in")    or "").strip()
    check_out   = (d.get("check_out")   or "").strip()

    if not room_number or not check_in or not check_out:
        return jsonify({"error": "Room, check-in and check-out are required"}), 400
    if check_out <= check_in:
        return jsonify({"error": "Check-out must be after check-in"}), 400

    room = query("SELECT * FROM rooms WHERE room_number=?", (room_number,), fetch="one")
    if not room:
        return jsonify({"error": "Room not found"}), 404
    if room["status"] == "Booked":
        return jsonify({"error": "Room is already booked"}), 409

    guest_name = user["full_name"] or user["username"]
    guest = query("SELECT id FROM guests WHERE user_id=?", (user_id,), fetch="one")
    guest_id = guest["id"] if guest else execute(
        "INSERT INTO guests (name,email,phone,user_id) VALUES (?,?,?,?)",
        (guest_name, user["email"], user["phone"], user_id)
    )

    execute("""
        INSERT INTO bookings (guest_id,room_id,check_in,check_out,num_guests,special_requests)
        VALUES (?,?,?,?,?,?)
    """, (guest_id, room["id"], check_in, check_out,
          int(d.get("num_guests", 1)), d.get("special_requests","")))

    execute("UPDATE rooms SET status='Booked' WHERE id=?", (room["id"],))
    log_activity(f"Customer booking — Room {room_number} ({guest_name})", "green")
    return jsonify({"ok": True})

@app.route("/api/customer/cancel/<int:booking_id>", methods=["PATCH"])
def customer_cancel(booking_id):
    d       = request.get_json(force=True) or {}
    user_id = d.get("user_id")
    booking = query("""
        SELECT b.* FROM bookings b
        JOIN guests g ON g.id = b.guest_id
        WHERE b.id=? AND g.user_id=?
    """, (booking_id, user_id), fetch="one")
    if not booking:
        return jsonify({"error": "Booking not found"}), 404
    if booking["status"] != "Active":
        return jsonify({"error": "Only active bookings can be cancelled"}), 400
    execute("UPDATE bookings SET status='Cancelled' WHERE id=?", (booking_id,))
    execute("UPDATE rooms SET status='Available' WHERE id=?", (booking["room_id"],))
    log_activity(f"Booking #{booking_id} cancelled by customer", "red")
    return jsonify({"ok": True})

# ── receptionist endpoints ───────────────────────────────────────────────────

@app.route("/api/receptionist/dashboard")
def receptionist_dashboard():
    today = __import__("datetime").date.today().isoformat()
    available  = query("SELECT COUNT(*) AS n FROM rooms WHERE status='Available'", fetch="one")["n"]
    booked     = query("SELECT COUNT(*) AS n FROM rooms WHERE status='Booked'",    fetch="one")["n"]
    maint      = query("SELECT COUNT(*) AS n FROM rooms WHERE status='Maintenance'",fetch="one")["n"]
    checked_in = query("SELECT COUNT(*) AS n FROM bookings WHERE status='Active'", fetch="one")["n"]
    checkins_today  = query("SELECT COUNT(*) AS n FROM bookings WHERE check_in=?  AND status IN ('Pending','Active')",   (today,), fetch="one")["n"]
    checkouts_today = query("SELECT COUNT(*) AS n FROM bookings WHERE check_out=? AND status='Active'",   (today,), fetch="one")["n"]
    requests   = query("SELECT COUNT(*) AS n FROM guest_requests WHERE status='Open'", fetch="one")
    open_reqs  = requests["n"] if requests else 0
    recent = query(
        "SELECT message, color, created_at FROM activity_log ORDER BY id DESC LIMIT 8"
    ) or []
    return jsonify({
        "available": available, "booked": booked, "maintenance": maint,
        "checked_in": checked_in, "checkins_today": checkins_today,
        "checkouts_today": checkouts_today, "open_requests": open_reqs,
        "recent_activity": recent
    })

@app.route("/api/receptionist/checkin/<int:booking_id>", methods=["PATCH"])
def receptionist_checkin(booking_id):
    booking = query("SELECT * FROM bookings WHERE id=?", (booking_id,), fetch="one")
    if not booking:
        return jsonify({"error": "Booking not found"}), 404
    if booking["status"] not in ("Pending", "Active"):
        return jsonify({"error": "Booking cannot be checked in"}), 400
    execute("UPDATE bookings SET status='Active' WHERE id=?", (booking_id,))
    execute("UPDATE rooms SET status='Booked' WHERE id=?", (booking["room_id"],))
    guest = query("SELECT name FROM guests WHERE id=?", (booking["guest_id"],), fetch="one")
    room  = query("SELECT room_number FROM rooms WHERE id=?", (booking["room_id"],), fetch="one")
    log_activity(f"Guest checked in — Room {room['room_number']} ({guest['name']})", "green")
    return jsonify({"ok": True})

@app.route("/api/receptionist/checkout/<int:booking_id>", methods=["PATCH"])
def receptionist_checkout(booking_id):
    booking = query("SELECT * FROM bookings WHERE id=?", (booking_id,), fetch="one")
    if not booking:
        return jsonify({"error": "Booking not found"}), 404
    if booking["status"] != "Active":
        return jsonify({"error": "Booking is not active"}), 400
    room  = query("SELECT * FROM rooms WHERE id=?", (booking["room_id"],), fetch="one")
    guest = query("SELECT name FROM guests WHERE id=?", (booking["guest_id"],), fetch="one")
    from datetime import date
    ci = booking["check_in"] if isinstance(booking["check_in"], date) else __import__("datetime").date.fromisoformat(str(booking["check_in"]))
    co = booking["check_out"] if isinstance(booking["check_out"], date) else __import__("datetime").date.fromisoformat(str(booking["check_out"]))
    nights = max((co - ci).days, 1)
    total  = float(room["price_per_night"]) * nights
    execute("UPDATE bookings SET status='Checked Out' WHERE id=?", (booking_id,))
    execute("UPDATE rooms SET status='Available' WHERE id=?", (room["id"],))
    log_activity(f"Checked out — Room {room['room_number']} ({guest['name']}) ZMW {total:.2f}", "red")
    return jsonify({"ok": True, "nights": nights, "total": total,
                    "guest": guest["name"], "room": room["room_number"],
                    "price_per_night": float(room["price_per_night"])})

@app.route("/api/receptionist/reports")
def receptionist_reports():
    today = __import__("datetime").date.today().isoformat()
    checkins_today  = query("SELECT COUNT(*) AS n FROM bookings WHERE check_in=?  AND status='Active'",      (today,), fetch="one")["n"]
    checkouts_today = query("SELECT COUNT(*) AS n FROM bookings WHERE check_out=? AND status='Checked Out'", (today,), fetch="one")["n"]
    total_rooms     = query("SELECT COUNT(*) AS n FROM rooms", fetch="one")["n"]
    booked_rooms    = query("SELECT COUNT(*) AS n FROM rooms WHERE status='Booked'", fetch="one")["n"]
    occupancy_pct   = round((booked_rooms / total_rooms * 100) if total_rooms else 0, 1)
    by_type = []
    for t in ["Single", "Double", "Deluxe"]:
        tot = query("SELECT COUNT(*) AS n FROM rooms WHERE room_type=?", (t,), fetch="one")["n"]
        bkd = query("SELECT COUNT(*) AS n FROM rooms WHERE room_type=? AND status='Booked'", (t,), fetch="one")["n"]
        by_type.append({"type": t, "total": tot, "booked": bkd})
    recent_checkouts = query("""
        SELECT b.id, b.check_in, b.check_out, g.name AS guest_name,
               r.room_number, r.room_type, r.price_per_night
        FROM bookings b
        JOIN guests g ON g.id = b.guest_id
        JOIN rooms  r ON r.id = b.room_id
        WHERE b.status='Checked Out'
        ORDER BY b.id DESC LIMIT 10
    """) or []
    return jsonify({
        "checkins_today": checkins_today, "checkouts_today": checkouts_today,
        "occupancy_pct": occupancy_pct, "by_type": by_type,
        "recent_checkouts": recent_checkouts
    })

# ── guest requests ────────────────────────────────────────────────────────────

@app.route("/api/requests", methods=["GET"])
def get_requests():
    rows = query("""
        SELECT r.id, r.room_number, r.request_type, r.description,
               r.status, r.created_at, g.name AS guest_name
        FROM guest_requests r
        LEFT JOIN guests g ON g.id = r.guest_id
        ORDER BY r.id DESC
    """) or []
    return jsonify(rows)

@app.route("/api/requests", methods=["POST"])
def add_request():
    d    = request.get_json(force=True) or {}
    room = (d.get("room_number")  or "").strip()
    rtype= (d.get("request_type") or "").strip()
    desc = (d.get("description")  or "").strip()
    if not room or not rtype:
        return jsonify({"error": "Room and request type are required"}), 400
    rid = execute(
        "INSERT INTO guest_requests (room_number, request_type, description, guest_id) VALUES (?,?,?,?)",
        (room, rtype, desc, d.get("guest_id"))
    )
    log_activity(f"Request logged — Room {room}: {rtype}", "purple")
    return jsonify({"ok": True, "id": rid})

@app.route("/api/requests/<int:req_id>/resolve", methods=["PATCH"])
def resolve_request(req_id):
    execute("UPDATE guest_requests SET status='Resolved' WHERE id=?", (req_id,))
    return jsonify({"ok": True})

# ── guest approval workflow ───────────────────────────────────────────────────

@app.route("/api/guest-approvals", methods=["GET"])
def get_guest_approvals():
    rows = query("""
        SELECT id, name, email, phone, requested_by, status, created_at
        FROM guest_approvals
        ORDER BY id DESC
    """) or []
    return jsonify(rows)

@app.route("/api/guest-approvals", methods=["POST"])
def request_guest_approval():
    d    = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Guest name is required"}), 400
    execute(
        "INSERT INTO guest_approvals (name, email, phone, requested_by) VALUES (?,?,?,?)",
        (name, d.get("email",""), d.get("phone",""), d.get("requested_by",""))
    )
    log_activity(f"Guest approval requested — {name} (by {d.get('requested_by','')})", "purple")
    return jsonify({"ok": True})

@app.route("/api/guest-approvals/<int:approval_id>/approve", methods=["PATCH"])
def approve_guest(approval_id):
    req = query("SELECT * FROM guest_approvals WHERE id=?", (approval_id,), fetch="one")
    if not req:
        return jsonify({"error": "Request not found"}), 404
    if req["status"] != "Pending":
        return jsonify({"error": "Already processed"}), 400
    gid = execute(
        "INSERT INTO guests (name, email, phone) VALUES (?,?,?)",
        (req["name"], req["email"], req["phone"])
    )
    execute("UPDATE guest_approvals SET status='Approved' WHERE id=?", (approval_id,))
    log_activity(f"Guest approved — {req['name']} (requested by {req['requested_by']})", "green")
    return jsonify({"ok": True, "guest_id": gid})

@app.route("/api/guest-approvals/<int:approval_id>/reject", methods=["PATCH"])
def reject_guest(approval_id):
    req = query("SELECT * FROM guest_approvals WHERE id=?", (approval_id,), fetch="one")
    if not req:
        return jsonify({"error": "Request not found"}), 404
    execute("UPDATE guest_approvals SET status='Rejected' WHERE id=?", (approval_id,))
    log_activity(f"Guest request rejected — {req['name']}", "red")
    return jsonify({"ok": True})

# ── admin receptionists ───────────────────────────────────────────────────────
@app.route("/api/admin/receptionists")
def admin_receptionists():
    rows = query("""
        SELECT id, username, full_name, email, phone, created_at
        FROM users
        WHERE role = 'customer'
        ORDER BY created_at DESC
    """) or []
    return jsonify(rows)

# ── serve frontend ────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return app.send_static_file("index.html")

if __name__ == "__main__":
    print("\n  Hotel Manager running at: http://localhost:5000\n")
    app.run(debug=True, port=5000)

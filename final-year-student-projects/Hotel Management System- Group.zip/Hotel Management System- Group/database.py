import mysql.connector

# ── Connection config — update these to match your XAMPP setup ────────────────
DB_CONFIG = {
    "host":     "localhost",
    "user":     "root",
    "password": "",          # XAMPP default is empty password
    "database": "hotel_db",
    "port":     3306
}

def get_db():
    conn = mysql.connector.connect(**DB_CONFIG)
    conn.autocommit = False
    return conn

def init_db():
    # Connect without specifying the database first, to create it if needed
    cfg = {k: v for k, v in DB_CONFIG.items() if k != "database"}
    conn = mysql.connector.connect(**cfg)
    c = conn.cursor()

    c.execute("CREATE DATABASE IF NOT EXISTS hotel_db")
    c.execute("USE hotel_db")

    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id         INT PRIMARY KEY AUTO_INCREMENT,
            username   VARCHAR(100) UNIQUE NOT NULL,
            password   VARCHAR(255) NOT NULL,
            role       VARCHAR(20) NOT NULL DEFAULT 'customer',
            full_name  VARCHAR(150) DEFAULT '',
            email      VARCHAR(150) DEFAULT '',
            phone      VARCHAR(50)  DEFAULT '',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS rooms (
            id              INT PRIMARY KEY AUTO_INCREMENT,
            room_number     VARCHAR(20) UNIQUE NOT NULL,
            room_type       VARCHAR(50) NOT NULL,
            floor           VARCHAR(20) NOT NULL,
            price_per_night DECIMAL(10,2) NOT NULL,
            status          VARCHAR(20) NOT NULL DEFAULT 'Available',
            description     TEXT DEFAULT ''
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS guests (
            id         INT PRIMARY KEY AUTO_INCREMENT,
            user_id    INT DEFAULT NULL,
            name       VARCHAR(150) NOT NULL,
            email      VARCHAR(150) DEFAULT '',
            phone      VARCHAR(50)  DEFAULT '',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS bookings (
            id               INT PRIMARY KEY AUTO_INCREMENT,
            guest_id         INT NOT NULL,
            room_id          INT NOT NULL,
            check_in         DATE NOT NULL,
            check_out        DATE NOT NULL,
            num_guests       INT DEFAULT 1,
            special_requests TEXT DEFAULT '',
            status           VARCHAR(20) NOT NULL DEFAULT 'Active',
            created_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (guest_id) REFERENCES guests(id),
            FOREIGN KEY (room_id)  REFERENCES rooms(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS guest_approvals (
            id         INT PRIMARY KEY AUTO_INCREMENT,
            name       VARCHAR(150) NOT NULL,
            email      VARCHAR(150) DEFAULT '',
            phone      VARCHAR(50)  DEFAULT '',
            requested_by VARCHAR(150) DEFAULT '',
            status     VARCHAR(20) NOT NULL DEFAULT 'Pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS guest_requests (
            id           INT PRIMARY KEY AUTO_INCREMENT,
            guest_id     INT DEFAULT NULL,
            room_number  VARCHAR(20) NOT NULL,
            request_type VARCHAR(100) NOT NULL,
            description  TEXT DEFAULT '',
            status       VARCHAR(20) NOT NULL DEFAULT 'Open',
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (guest_id) REFERENCES guests(id) ON DELETE SET NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS activity_log (
            id         INT PRIMARY KEY AUTO_INCREMENT,
            message    TEXT NOT NULL,
            color      VARCHAR(20) NOT NULL DEFAULT 'blue',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Default admin — only insert if not already there
    c.execute("""
        INSERT IGNORE INTO users (username, password, role, full_name)
        VALUES ('admin', 'admin', 'admin', 'Administrator')
    """)

    conn.commit()
    conn.close()

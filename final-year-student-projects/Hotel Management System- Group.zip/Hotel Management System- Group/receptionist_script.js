﻿// auth guard
if (localStorage.getItem("hotel_role") !== "customer") window.location.href = "index.html";

const userName  = localStorage.getItem("hotel_full_name") || localStorage.getItem("hotel_user") || "Receptionist";
const colorMap  = {green:"dot-green",red:"dot-red",blue:"dot-blue",purple:"dot-purple"};
const gradients = ["linear-gradient(135deg,#1a73e8,#4a9eff)","linear-gradient(135deg,#9334e6,#b96af5)","linear-gradient(135deg,#34a853,#5dc97a)","linear-gradient(135deg,#ea4335,#ff7b6b)","linear-gradient(135deg,#f57c00,#ffb74d)","linear-gradient(135deg,#1a1a2e,#533483)"];
const typeBadge = {Single:"badge-single",Double:"badge-double",Deluxe:"badge-deluxe"};

document.getElementById("today-date").textContent = new Date().toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
document.getElementById("welcome-name").textContent = userName;
document.getElementById("avatar-initials").textContent = userName.slice(0,2).toUpperCase();
document.getElementById("sidebar-user").innerHTML =
  `<div style="font-size:0.8rem;color:#fff;font-weight:600;">${userName}</div>
   <div style="font-size:0.7rem;color:#aaa;">Receptionist</div>`;

// ── NAVIGATION ───────────────────────────────────────────────────────────────
const sections = ["dashboard","rooms","bookings","checkin","checkout","guests","requests","reports"];
const titles   = {dashboard:"Dashboard",rooms:"Room Management",bookings:"Reservations",checkin:"Check-In",checkout:"Check-Out & Billing",guests:"Guest Management",requests:"Guest Requests",reports:"Daily Reports"};
const icons    = {dashboard:"fa-gauge-high",rooms:"fa-door-open",bookings:"fa-calendar-check",checkin:"fa-right-to-bracket",checkout:"fa-right-from-bracket",guests:"fa-users",requests:"fa-bell",reports:"fa-chart-bar"};

function nav(name) {
  sections.forEach(s => {
    document.getElementById("sec-"+s).classList.toggle("sec-hidden", s !== name);
    document.getElementById("nav-"+s).classList.toggle("active", s === name);
  });
  document.getElementById("topbar-title").innerHTML = `<i class="fa-solid ${icons[name]}"></i> &nbsp;${titles[name]}`;
  if (name === "dashboard") loadDashboard();
  if (name === "rooms")     loadRooms();
  if (name === "bookings")  loadBookings();
  if (name === "checkin")   loadCheckin();
  if (name === "checkout")  loadCheckout();
  if (name === "guests")    { loadGuests(); loadMyApprovals(); }
  if (name === "requests")  loadRequests();
  if (name === "reports")   loadReports();
  return false;
}

function showMsg(text, ok=true) {
  const el = document.getElementById("msg-global");
  el.textContent = text;
  el.style.display = "block";
  el.style.background = ok ? "#e6f4ea" : "#fce8e6";
  el.style.color = ok ? "#34a853" : "#ea4335";
  setTimeout(() => el.style.display = "none", 3500);
}

function openModal(id)  { document.getElementById(id).classList.add("open"); }
function closeModal(id) { document.getElementById(id).classList.remove("open"); }
function closeBill()    { closeModal("bill-modal"); }

// ── DASHBOARD ────────────────────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const res = await fetch("/api/receptionist/dashboard", {credentials:"include"});
    const d   = await res.json();
    document.getElementById("d-available").textContent = d.available;
    document.getElementById("d-booked").textContent    = d.booked;
    document.getElementById("d-maint").textContent     = d.maintenance;
    document.getElementById("d-checkedin").textContent = d.checked_in;
    document.getElementById("d-cin").textContent       = d.checkins_today;
    document.getElementById("d-cout").textContent      = d.checkouts_today;
    document.getElementById("d-reqs").textContent      = d.open_requests;
    // update sidebar requests badge
    const reqBadge = document.getElementById("nav-requests");
    if (d.open_requests > 0) {
      reqBadge.innerHTML = `<i class="fa-solid fa-bell"></i><span>Requests <span style="background:#ea4335;color:#fff;border-radius:10px;padding:1px 7px;font-size:0.7rem;margin-left:4px;">${d.open_requests}</span></span>`;
    }
    const listEl = document.getElementById("d-activity");
    if (!d.recent_activity || !d.recent_activity.length) {
      listEl.innerHTML = '<li style="color:#aaa;font-size:0.85rem;padding:20px 0;text-align:center;">No activity yet.</li>';
      return;
    }
    listEl.innerHTML = d.recent_activity.map(a => {
      const dot  = colorMap[a.color] || "dot-blue";
      const time = new Date(a.created_at).toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"});
      return `<li><span class="activity-dot ${dot}"></span>${a.message}<span class="activity-time">${time}</span></li>`;
    }).join("");
  } catch(e) { console.error("Dashboard error:", e); }
}

// ── ROOMS ────────────────────────────────────────────────────────────────────
let allRooms = [];
async function loadRooms() {
  const res = await fetch("/api/rooms", {credentials:"include"});
  allRooms  = await res.json();
  renderRooms(allRooms);
}
function renderRooms(list) {
  const grid = document.getElementById("rooms-grid");
  if (!list.length) { grid.innerHTML = '<div class="empty-state"><i class="fa-solid fa-door-open"></i><p>No rooms found.</p></div>'; return; }
  grid.innerHTML = list.map(r => {
    const cls = r.status==="Available"?"available":r.status==="Booked"?"booked":"maintenance";
    const bc  = r.status==="Available"?"badge-available":r.status==="Booked"?"badge-booked":"badge-single";
    return `<div class="room-tile ${cls}">
      <h4><i class="fa-solid fa-door-open"></i> Room ${r.room_number}</h4>
      <div class="rt-meta">${r.room_type} | Floor ${r.floor}</div>
      <div class="rt-price">ZMW ${parseFloat(r.price_per_night).toFixed(2)} <span style="font-size:0.75rem;font-weight:400;color:#aaa;">/ night</span></div>
      <div style="margin-bottom:10px;"><span class="badge ${bc}">${r.status}</span></div>
      <div class="rt-actions">
        ${r.status!=="Available"   ? `<button class="btn-secondary" style="padding:5px 10px;font-size:0.75rem;" onclick="setRoomStatus(${r.id},'Available')">Set Available</button>` : ""}
        ${r.status!=="Maintenance" ? `<button class="btn-secondary" style="padding:5px 10px;font-size:0.75rem;color:#f57c00;" onclick="setRoomStatus(${r.id},'Maintenance')">Maintenance</button>` : ""}
        ${r.status==="Available"   ? `<button class="btn-secondary" style="padding:5px 10px;font-size:0.75rem;color:#1a73e8;" onclick="nav('bookings');openNewBookingModal()">Book Room</button>` : ""}
      </div>
    </div>`;
  }).join("");
}
function filterRooms(status, btn) {
  document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  renderRooms(status==="all" ? allRooms : allRooms.filter(r => r.status===status));
}
async function setRoomStatus(id, status) {
  const res  = await fetch(`/api/rooms/${id}/status`, {method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status}),credentials:"include"});
  const data = await res.json();
  if (data.ok) { showMsg(`Room set to ${status}.`); loadRooms(); loadDashboard(); }
  else showMsg(data.error||"Failed.", false);
}

// ── BOOKINGS ─────────────────────────────────────────────────────────────────
let allBookings = [];
async function loadBookings() {
  const res   = await fetch("/api/bookings", {credentials:"include"});
  allBookings = await res.json();
  renderBookings(allBookings);
}
function renderBookings(list) {
  const el = document.getElementById("bookings-list");
  if (!list.length) { el.innerHTML = '<div class="empty-state"><i class="fa-solid fa-calendar-xmark"></i><p>No bookings yet.</p></div>'; return; }
  el.innerHTML = list.map(b => {
    const cls  = b.status==="Active"?"active":b.status==="Checked Out"?"checkout":b.status==="Pending"?"active":"cancelled";
    const icon = b.status==="Active"?"fa-bed":b.status==="Pending"?"fa-clock":b.status==="Checked Out"?"fa-door-open":"fa-xmark";
    const nights = Math.max(Math.ceil((new Date(b.check_out)-new Date(b.check_in))/86400000),1);
    const total  = (nights*parseFloat(b.price_per_night)).toFixed(2);
    return `<div class="bk-card">
      <div class="bk-icon ${cls}"><i class="fa-solid ${icon}"></i></div>
      <div class="bk-info">
        <h4>${b.guest_name} &nbsp;<span class="badge ${typeBadge[b.room_type]||''}">${b.room_type}</span></h4>
        <p><i class="fa-solid fa-door-open"></i> Room ${b.room_number} | <i class="fa-regular fa-calendar"></i> ${b.check_in} to ${b.check_out} | ${nights} night(s)</p>
        <p><i class="fa-solid fa-tag"></i> ZMW ${total} | Guests: ${b.num_guests}${b.special_requests ? ` | ${b.special_requests}` : ""}</p>
      </div>
      <div class="bk-actions">
        <span class="badge ${b.status==="Active"?"badge-booked":b.status==="Checked Out"?"badge-available":"badge-single"}">${b.status}</span>
        ${b.status==="Pending" ? `<button class="btn-submit" style="padding:5px 12px;font-size:0.78rem;" onclick="doCheckin(${b.id})"><i class="fa-solid fa-right-to-bracket"></i> Check In</button>` : ""}
        ${b.status==="Active"  ? `<button class="btn-submit" style="padding:5px 12px;font-size:0.78rem;background:linear-gradient(135deg,#ea4335,#ff7b6b);" onclick="showBillFromBooking(${b.id},'${b.guest_name}','${b.room_number}','${b.room_type}','${b.check_in}','${b.check_out}',${b.price_per_night},${nights},${total})"><i class="fa-solid fa-right-from-bracket"></i> Check Out</button>` : ""}
        ${(b.status==="Pending"||b.status==="Active") ? `<button class="btn-secondary" style="padding:5px 12px;font-size:0.78rem;color:#ea4335;" onclick="cancelBooking(${b.id})"><i class="fa-solid fa-xmark"></i> Cancel</button>` : ""}
      </div>
    </div>`;
  }).join("");
}
function filterBookings() {
  const q = document.getElementById("bk-search").value.toLowerCase();
  renderBookings(allBookings.filter(b => b.guest_name.toLowerCase().includes(q)||b.room_number.toLowerCase().includes(q)));
}
async function cancelBooking(id) {
  if (!confirm("Cancel this booking? The room will be freed.")) return;
  const res  = await fetch(`/api/bookings/${id}`, {method:"DELETE",credentials:"include"});
  const data = await res.json();
  if (data.ok) { showMsg("Booking cancelled."); loadBookings(); loadRooms(); loadDashboard(); }
  else showMsg(data.error||"Failed.", false);
}
async function openNewBookingModal() {
  const res   = await fetch("/api/rooms/available", {credentials:"include"});
  const rooms = await res.json();
  const sel   = document.getElementById("nb-room");
  sel.innerHTML = '<option value="">Select available room</option>';
  rooms.forEach(r => sel.innerHTML += `<option value="${r.room_number}">${r.room_number} - ${r.room_type} (ZMW ${r.price_per_night}/night)</option>`);
  const today = new Date().toISOString().split("T")[0];
  document.getElementById("nb-checkin").min  = today;
  document.getElementById("nb-checkout").min = today;
  ["nb-name","nb-email","nb-phone","nb-notes"].forEach(id => document.getElementById(id).value="");
  document.getElementById("nb-msg").style.display = "none";
  openModal("new-booking-modal");
}
async function submitNewBooking() {
  const payload = {
    guest_name: document.getElementById("nb-name").value.trim(),
    email:      document.getElementById("nb-email").value.trim(),
    phone:      document.getElementById("nb-phone").value.trim(),
    room_number:document.getElementById("nb-room").value,
    check_in:   document.getElementById("nb-checkin").value,
    check_out:  document.getElementById("nb-checkout").value,
    num_guests: parseInt(document.getElementById("nb-guests").value),
    special_requests: document.getElementById("nb-notes").value.trim()
  };
  const msgEl = document.getElementById("nb-msg");
  if (!payload.guest_name||!payload.room_number||!payload.check_in||!payload.check_out) {
    msgEl.textContent="Fill in all required fields."; msgEl.style.display="block"; msgEl.style.background="#fce8e6"; msgEl.style.color="#ea4335"; return;
  }
  const res  = await fetch("/api/bookings", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload),credentials:"include"});
  const data = await res.json();
  if (data.ok) {
    closeModal("new-booking-modal"); showMsg("Booking created! Guest can now check in.");
    loadBookings(); loadRooms(); loadDashboard();
  } else { msgEl.textContent=data.error||"Failed."; msgEl.style.display="block"; msgEl.style.background="#fce8e6"; msgEl.style.color="#ea4335"; }
}

// ── CHECK-IN ─────────────────────────────────────────────────────────────────
async function loadCheckin() {
  const res = await fetch("/api/bookings", {credentials:"include"});
  const all = await res.json();
  const pending = all.filter(b => b.status==="Pending");
  const el = document.getElementById("checkin-results");
  if (!pending.length) { el.innerHTML = '<div class="empty-state"><i class="fa-solid fa-right-to-bracket"></i><p>No pending check-ins.</p></div>'; return; }
  el.innerHTML = pending.map(b => {
    const nights = Math.max(Math.ceil((new Date(b.check_out)-new Date(b.check_in))/86400000),1);
    return `<div class="bk-card">
      <div class="bk-icon active"><i class="fa-solid fa-clock"></i></div>
      <div class="bk-info">
        <h4>${b.guest_name} &nbsp;<span class="badge ${typeBadge[b.room_type]||''}">${b.room_type}</span></h4>
        <p><i class="fa-solid fa-door-open"></i> Room ${b.room_number} | <i class="fa-regular fa-calendar"></i> ${b.check_in} to ${b.check_out} (${nights} nights)</p>
        <p>Guests: ${b.num_guests}${b.special_requests ? ` | Requests: ${b.special_requests}` : ""}</p>
      </div>
      <div class="bk-actions">
        <span class="badge badge-single">Pending</span>
        <button class="btn-submit" style="padding:6px 14px;font-size:0.8rem;" onclick="doCheckin(${b.id})"><i class="fa-solid fa-right-to-bracket"></i> Confirm Check-In</button>
      </div>
    </div>`;
  }).join("");
}
async function searchCheckin() {
  const q   = document.getElementById("ci-search").value.trim().toLowerCase();
  const res = await fetch("/api/bookings", {credentials:"include"});
  const all = await res.json();
  const matches = all.filter(b => b.status==="Pending" && b.guest_name.toLowerCase().includes(q));
  const el = document.getElementById("checkin-results");
  if (!matches.length) { el.innerHTML = '<div class="empty-state"><i class="fa-solid fa-magnifying-glass"></i><p>No pending bookings found for that name.</p></div>'; return; }
  el.innerHTML = matches.map(b => {
    const nights = Math.max(Math.ceil((new Date(b.check_out)-new Date(b.check_in))/86400000),1);
    return `<div class="bk-card">
      <div class="bk-icon active"><i class="fa-solid fa-right-to-bracket"></i></div>
      <div class="bk-info">
        <h4>${b.guest_name} &nbsp;<span class="badge ${typeBadge[b.room_type]||''}">${b.room_type}</span></h4>
        <p><i class="fa-solid fa-door-open"></i> Room ${b.room_number} | <i class="fa-regular fa-calendar"></i> ${b.check_in} to ${b.check_out} (${nights} nights)</p>
        <p>Guests: ${b.num_guests}${b.special_requests ? ` | Requests: ${b.special_requests}` : ""}</p>
      </div>
      <div class="bk-actions">
        <button class="btn-submit" style="padding:6px 14px;font-size:0.8rem;" onclick="doCheckin(${b.id})"><i class="fa-solid fa-check"></i> Confirm Check-In</button>
      </div>
    </div>`;
  }).join("");
}
async function doCheckin(id) {
  const res  = await fetch(`/api/receptionist/checkin/${id}`, {method:"PATCH",credentials:"include"});
  const data = await res.json();
  if (data.ok) {
    showMsg("Guest checked in successfully!");
    loadCheckin(); loadDashboard(); loadRooms();
    if (document.getElementById("bookings-list").innerHTML) loadBookings();
  } else showMsg(data.error||"Failed.", false);
}

// ── CHECK-OUT & BILLING ───────────────────────────────────────────────────────
async function loadCheckout() {
  const res    = await fetch("/api/bookings", {credentials:"include"});
  const all    = await res.json();
  const active = all.filter(b => b.status==="Active");
  const el     = document.getElementById("checkout-list");
  if (!active.length) { el.innerHTML = '<div class="empty-state"><i class="fa-solid fa-door-open"></i><p>No guests currently checked in.</p></div>'; return; }
  el.innerHTML = active.map(b => {
    const nights = Math.max(Math.ceil((new Date(b.check_out)-new Date(b.check_in))/86400000),1);
    const total  = (nights*parseFloat(b.price_per_night)).toFixed(2);
    return `<div class="bk-card">
      <div class="bk-icon active"><i class="fa-solid fa-bed"></i></div>
      <div class="bk-info">
        <h4>${b.guest_name} &nbsp;<span class="badge ${typeBadge[b.room_type]||''}">${b.room_type}</span></h4>
        <p><i class="fa-solid fa-door-open"></i> Room ${b.room_number} | <i class="fa-regular fa-calendar"></i> ${b.check_in} to ${b.check_out}</p>
        <p><i class="fa-solid fa-tag"></i> ZMW ${b.price_per_night}/night x ${nights} nights = <strong>ZMW ${total}</strong></p>
      </div>
      <div class="bk-actions">
        <button class="btn-secondary" style="padding:6px 14px;font-size:0.8rem;" onclick="showBillFromBooking(${b.id},'${b.guest_name}','${b.room_number}','${b.room_type}','${b.check_in}','${b.check_out}',${b.price_per_night},${nights},${total})">
          <i class="fa-solid fa-receipt"></i> Bill
        </button>
        <button class="btn-submit" style="padding:6px 14px;font-size:0.8rem;background:linear-gradient(135deg,#ea4335,#ff7b6b);" onclick="processCheckout(${b.id})">
          <i class="fa-solid fa-right-from-bracket"></i> Check Out
        </button>
      </div>
    </div>`;
  }).join("");
}
function showBillFromBooking(id, guest, room, type, ci, co, ppn, nights, total) {
  document.getElementById("bill-body").innerHTML = `
    <div class="bill-row"><span>Guest</span><strong>${guest}</strong></div>
    <div class="bill-row"><span>Room</span><strong>${room} (${type})</strong></div>
    <div class="bill-row"><span>Check-in</span><strong>${ci}</strong></div>
    <div class="bill-row"><span>Check-out</span><strong>${co}</strong></div>
    <div class="bill-row"><span>Rate / Night</span><strong>ZMW ${parseFloat(ppn).toFixed(2)}</strong></div>
    <div class="bill-row"><span>Nights</span><strong>${nights}</strong></div>
    <div class="bill-row total"><span>Total</span><strong>ZMW ${parseFloat(total).toFixed(2)}</strong></div>
    <button class="btn-print" onclick="window.print()"><i class="fa-solid fa-print"></i> &nbsp;Print Bill</button>
    <button class="btn-confirm" style="margin-top:8px;background:linear-gradient(135deg,#ea4335,#ff7b6b);" onclick="processCheckout(${id})"><i class="fa-solid fa-right-from-bracket"></i> &nbsp;Confirm Check-Out</button>`;
  openModal("bill-modal");
}
async function processCheckout(id) {
  const res  = await fetch(`/api/receptionist/checkout/${id}`, {method:"PATCH",credentials:"include"});
  const data = await res.json();
  if (data.ok) {
    closeBill();
    showMsg(`${data.guest} checked out. Total: ZMW ${parseFloat(data.total).toFixed(2)}`);
    loadCheckout(); loadDashboard(); loadRooms(); loadReports();
    if (allBookings.length) loadBookings();
  } else showMsg(data.error||"Failed.", false);
}

// ── GUESTS ────────────────────────────────────────────────────────────────────
let allGuests = [];
async function loadGuests() {
  const res = await fetch("/api/guests", {credentials:"include"});
  allGuests = await res.json();
  renderGuests(allGuests);
}
function renderGuests(list) {
  const grid = document.getElementById("guests-grid");
  if (!list.length) { grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><i class="fa-solid fa-users"></i><p>No guests found.</p></div>'; return; }
  grid.innerHTML = list.map((g,i) => {
    const initials = g.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase();
    const grad = gradients[i % gradients.length];
    const statusBadge = g.booking_status==="Active"
      ? '<span class="badge badge-booked">Checked In</span>'
      : g.booking_status==="Checked Out"
        ? '<span class="badge badge-available">Checked Out</span>'
        : '<span style="color:#aaa;font-size:0.78rem;">No booking</span>';
    return `<div class="guest-card">
      <div class="guest-avatar" style="background:${grad};">${initials}</div>
      <div class="guest-info">
        <h4>${g.name}</h4>
        <p>${g.email||"—"} | ${g.phone||"—"}</p>
        <p style="margin-top:4px;">${statusBadge}${g.room_number ? ` &nbsp;Room ${g.room_number}` : ""}</p>
        <button class="btn-secondary" style="padding:4px 10px;font-size:0.75rem;margin-top:8px;color:#1a73e8;" onclick="nav('bookings');openNewBookingModal()">
          <i class="fa-solid fa-calendar-plus"></i> Book
        </button>
      </div>
    </div>`;
  }).join("");
}
function filterGuests() {
  const q = document.getElementById("guest-search").value.toLowerCase();
  renderGuests(allGuests.filter(g => g.name.toLowerCase().includes(q)||(g.email||"").toLowerCase().includes(q)));
}
function openAddGuestModal() {
  ["ag-name","ag-email","ag-phone"].forEach(id => document.getElementById(id).value="");
  document.getElementById("ag-msg").style.display="none";
  openModal("add-guest-modal");
}
async function submitAddGuest() {
  const name  = document.getElementById("ag-name").value.trim();
  const msgEl = document.getElementById("ag-msg");
  if (!name) { msgEl.textContent="Name is required."; msgEl.style.display="block"; msgEl.style.background="#fce8e6"; msgEl.style.color="#ea4335"; return; }
  const res  = await fetch("/api/guest-approvals", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({
      name,
      email: document.getElementById("ag-email").value.trim(),
      phone: document.getElementById("ag-phone").value.trim(),
      requested_by: userName
    }),
    credentials:"include"
  });
  const data = await res.json();
  if (data.ok) {
    closeModal("add-guest-modal");
    showMsg("Request submitted! Waiting for admin approval.");
    loadMyApprovals();
  } else { msgEl.textContent=data.error||"Failed."; msgEl.style.display="block"; msgEl.style.background="#fce8e6"; msgEl.style.color="#ea4335"; }
}

async function loadMyApprovals() {
  const res  = await fetch("/api/guest-approvals", {credentials:"include"});
  const list = await res.json();
  const mine = list.filter(r => r.requested_by === userName);
  const el   = document.getElementById("my-approvals");
  if (!el) return;
  if (!mine.length) { el.innerHTML = '<p style="color:#aaa;font-size:0.85rem;padding:12px 0;">No requests submitted yet.</p>'; return; }
  el.innerHTML = mine.map(r => {
    const badgeCls = r.status==="Approved"?"badge-available":r.status==="Rejected"?"badge-booked":"badge-single";
    const time = new Date(r.created_at).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"});
    return `<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f0f0f0;flex-wrap:wrap;gap:8px;">
      <div>
        <div style="font-weight:600;font-size:0.88rem;">${r.name}</div>
        <div style="font-size:0.75rem;color:#aaa;">${r.email||"—"} | ${r.phone||"—"} | ${time}</div>
      </div>
      <span class="badge ${badgeCls}">${r.status}</span>
    </div>`;
  }).join("");
}

// ── REQUESTS ──────────────────────────────────────────────────────────────────
async function loadRequests() {
  const res  = await fetch("/api/requests", {credentials:"include"});
  const list = await res.json();
  const el   = document.getElementById("requests-list");
  if (!list.length) { el.innerHTML = '<div class="empty-state"><i class="fa-solid fa-bell-slash"></i><p>No requests logged.</p></div>'; return; }
  el.innerHTML = list.map(r => {
    const resolved = r.status==="Resolved";
    const time = new Date(r.created_at).toLocaleString("en-US",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});
    return `<div class="req-card">
      <div class="req-icon ${resolved?"resolved":""}"><i class="fa-solid ${resolved?"fa-check":"fa-bell"}"></i></div>
      <div class="req-info">
        <h4>${r.request_type} — Room ${r.room_number}${r.guest_name ? ` (${r.guest_name})` : ""}</h4>
        <p>${r.description||"No description"} | ${time}</p>
      </div>
      <div style="flex-shrink:0;">
        <span class="badge ${resolved?"badge-available":"badge-booked"}">${r.status}</span>
        ${!resolved ? `<button class="btn-secondary" style="padding:5px 10px;font-size:0.75rem;margin-left:8px;" onclick="resolveRequest(${r.id})">Resolve</button>` : ""}
      </div>
    </div>`;
  }).join("");
}
function openRequestModal() {
  ["rq-room","rq-desc"].forEach(id => document.getElementById(id).value="");
  document.getElementById("rq-msg").style.display="none";
  openModal("request-modal");
}
async function submitRequest() {
  const room  = document.getElementById("rq-room").value.trim();
  const type  = document.getElementById("rq-type").value;
  const desc  = document.getElementById("rq-desc").value.trim();
  const msgEl = document.getElementById("rq-msg");
  if (!room) { msgEl.textContent="Room number is required."; msgEl.style.display="block"; msgEl.style.background="#fce8e6"; msgEl.style.color="#ea4335"; return; }
  const res  = await fetch("/api/requests", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({room_number:room,request_type:type,description:desc}),credentials:"include"});
  const data = await res.json();
  if (data.ok) { closeModal("request-modal"); showMsg("Request logged."); loadRequests(); loadDashboard(); }
  else { msgEl.textContent=data.error||"Failed."; msgEl.style.display="block"; msgEl.style.background="#fce8e6"; msgEl.style.color="#ea4335"; }
}
async function resolveRequest(id) {
  const res  = await fetch(`/api/requests/${id}/resolve`, {method:"PATCH",credentials:"include"});
  const data = await res.json();
  if (data.ok) { showMsg("Request resolved."); loadRequests(); loadDashboard(); }
  else showMsg(data.error||"Failed.", false);
}

// ── REPORTS ───────────────────────────────────────────────────────────────────
async function loadReports() {
  const res = await fetch("/api/receptionist/reports", {credentials:"include"});
  const d   = await res.json();
  document.getElementById("rp-cin").textContent  = d.checkins_today;
  document.getElementById("rp-cout").textContent = d.checkouts_today;
  document.getElementById("rp-occ").textContent  = d.occupancy_pct + "%";
  const fillColors = {Single:"fill-blue",Double:"fill-green",Deluxe:"fill-purple"};
  document.getElementById("rp-bars").innerHTML = d.by_type.map(o => {
    const pct = o.total ? Math.round((o.booked/o.total)*100) : 0;
    return `<div class="occ-bar">
      <div class="occ-label"><span>${o.type} Rooms</span><span>${o.booked} / ${o.total} (${pct}%)</span></div>
      <div class="progress-bar"><div class="progress-fill ${fillColors[o.type]||'fill-blue'}" style="width:${pct}%"></div></div>
    </div>`;
  }).join("");
  const tbody = document.getElementById("rp-table");
  if (!d.recent_checkouts.length) { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#aaa;padding:20px;">No check-outs yet.</td></tr>'; return; }
  tbody.innerHTML = d.recent_checkouts.map(b => {
    const nights = Math.max(Math.ceil((new Date(b.check_out)-new Date(b.check_in))/86400000),1);
    const total  = (nights*parseFloat(b.price_per_night)).toFixed(2);
    return `<tr><td>${b.guest_name}</td><td>${b.room_number} <span class="badge ${typeBadge[b.room_type]||''}">${b.room_type}</span></td><td>${b.check_in}</td><td>${b.check_out}</td><td>${nights}</td><td>ZMW ${total}</td></tr>`;
  }).join("");
}

// ── LOGOUT ────────────────────────────────────────────────────────────────────
async function doLogout() {
  await fetch("/api/logout", {method:"POST",credentials:"include"});
  localStorage.clear();
  window.location.href = "index.html";
}

// close modals on overlay click
document.querySelectorAll(".modal-overlay").forEach(el => {
  el.addEventListener("click", function(e) { if (e.target===this) this.classList.remove("open"); });
});

// boot — load dashboard on start
loadDashboard();

from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import db, Billing, Service, Patient, Appointment
from datetime import datetime

billing_bp = Blueprint('billing', __name__, url_prefix='/billing')

@billing_bp.route('/')
@login_required
def list_billing():
    status = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    
    query = Billing.query
    
    if status:
        query = query.filter_by(status=status)
    
    bills = query.order_by(Billing.created_at.desc()).paginate(page=page, per_page=10)
    
    # Calculate totals
    total_pending = db.session.query(db.func.sum(Billing.amount)).filter(Billing.status == 'pending').scalar() or 0
    total_paid = db.session.query(db.func.sum(Billing.amount)).filter(Billing.status == 'paid').scalar() or 0
    
    return render_template('billing/list.html', 
                         bills=bills, 
                         status_filter=status,
                         total_pending=round(total_pending, 2),
                         total_paid=round(total_paid, 2))

@billing_bp.route('/services')
@login_required
def manage_services():
    page = request.args.get('page', 1, type=int)
    services = Service.query.paginate(page=page, per_page=10)
    return render_template('billing/services.html', services=services)

@billing_bp.route('/services/new', methods=['GET', 'POST'])
@login_required
def new_service():
    if request.method == 'POST':
        try:
            service = Service(
                name=request.form.get('name'),
                description=request.form.get('description'),
                cost=float(request.form.get('cost'))
            )
            
            db.session.add(service)
            db.session.commit()
            
            flash('Service added successfully!', 'success')
            return redirect(url_for('billing.manage_services'))
        except Exception as e:
            db.session.rollback()
            flash('Error adding service: ' + str(e), 'danger')
            return redirect(url_for('billing.new_service'))
    
    return render_template('billing/service_form.html')

@billing_bp.route('/services/<int:service_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_service(service_id):
    service = Service.query.get_or_404(service_id)
    
    if request.method == 'POST':
        try:
            service.name = request.form.get('name')
            service.description = request.form.get('description')
            service.cost = float(request.form.get('cost'))
            
            db.session.commit()
            
            flash('Service updated successfully!', 'success')
            return redirect(url_for('billing.manage_services'))
        except Exception as e:
            db.session.rollback()
            flash('Error updating service: ' + str(e), 'danger')
    
    return render_template('billing/service_form.html', service=service)

@billing_bp.route('/services/<int:service_id>/delete', methods=['POST'])
@login_required
def delete_service(service_id):
    service = Service.query.get_or_404(service_id)
    
    try:
        db.session.delete(service)
        db.session.commit()
        flash('Service deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting service: ' + str(e), 'danger')
    
    return redirect(url_for('billing.manage_services'))

@billing_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new_billing():
    patients = Patient.query.all()
    appointments = Appointment.query.filter_by(status='completed').all()
    services = Service.query.all()
    
    if request.method == 'POST':
        try:
            patient_id = int(request.form.get('patient_id'))
            service_id = request.form.get('service_id')
            appointment_id = request.form.get('appointment_id')
            amount = float(request.form.get('amount'))
            
            billing = Billing(
                patient_id=patient_id,
                service_id=int(service_id) if service_id else None,
                appointment_id=int(appointment_id) if appointment_id else None,
                amount=amount,
                status='pending'
            )
            
            db.session.add(billing)
            db.session.commit()
            
            flash('Bill created successfully!', 'success')
            return redirect(url_for('billing.list_billing'))
        except Exception as e:
            db.session.rollback()
            flash('Error creating bill: ' + str(e), 'danger')
            return redirect(url_for('billing.new_billing'))
    
    return render_template('billing/form.html', 
                         patients=patients, 
                         appointments=appointments,
                         services=services)

@billing_bp.route('/<int:billing_id>')
@login_required
def view_billing(billing_id):
    billing = Billing.query.get_or_404(billing_id)
    return render_template('billing/view.html', billing=billing)

@billing_bp.route('/<int:billing_id>/mark-paid', methods=['POST'])
@login_required
def mark_paid(billing_id):
    billing = Billing.query.get_or_404(billing_id)
    
    try:
        billing.status = 'paid'
        billing.paid_at = datetime.utcnow()
        db.session.commit()
        flash('Bill marked as paid!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error updating bill: ' + str(e), 'danger')
    
    return redirect(url_for('billing.view_billing', billing_id=billing.id))

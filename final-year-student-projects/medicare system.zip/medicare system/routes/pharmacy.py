from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import db, Medicine, Prescription, PrescriptionItem, PharmacySale, PharmacySaleItem, Patient, Doctor
from datetime import datetime

pharmacy_bp = Blueprint('pharmacy', __name__, url_prefix='/pharmacy')

# ---- Medicines ----
@pharmacy_bp.route('/')
@login_required
def index():
    medicines = Medicine.query.order_by(Medicine.name).all()
    low_stock = Medicine.query.filter(Medicine.stock_quantity <= Medicine.reorder_level).count()
    out_of_stock = Medicine.query.filter(Medicine.stock_quantity == 0).count()
    total_medicines = Medicine.query.count()
    pending_prescriptions = Prescription.query.filter_by(status='pending').count()
    return render_template('pharmacy/index.html', medicines=medicines,
                           low_stock=low_stock, out_of_stock=out_of_stock,
                           total_medicines=total_medicines,
                           pending_prescriptions=pending_prescriptions)

@pharmacy_bp.route('/medicines/new', methods=['GET', 'POST'])
@login_required
def new_medicine():
    if request.method == 'POST':
        try:
            med = Medicine(
                name=request.form['name'],
                generic_name=request.form.get('generic_name'),
                category=request.form['category'],
                manufacturer=request.form.get('manufacturer'),
                unit_price=float(request.form['unit_price']),
                stock_quantity=int(request.form.get('stock_quantity', 0)),
                reorder_level=int(request.form.get('reorder_level', 10)),
                expiry_date=datetime.strptime(request.form['expiry_date'], '%Y-%m-%d').date() if request.form.get('expiry_date') else None,
                description=request.form.get('description')
            )
            db.session.add(med)
            db.session.commit()
            flash('Medicine added successfully!', 'success')
            return redirect(url_for('pharmacy.index'))
        except Exception as e:
            db.session.rollback()
            flash('Error adding medicine: ' + str(e), 'danger')
    return render_template('pharmacy/medicine_form.html')

@pharmacy_bp.route('/medicines/<int:med_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_medicine(med_id):
    med = Medicine.query.get_or_404(med_id)
    if request.method == 'POST':
        try:
            med.name = request.form['name']
            med.generic_name = request.form.get('generic_name')
            med.category = request.form['category']
            med.manufacturer = request.form.get('manufacturer')
            med.unit_price = float(request.form['unit_price'])
            med.stock_quantity = int(request.form.get('stock_quantity', 0))
            med.reorder_level = int(request.form.get('reorder_level', 10))
            med.expiry_date = datetime.strptime(request.form['expiry_date'], '%Y-%m-%d').date() if request.form.get('expiry_date') else None
            med.description = request.form.get('description')
            db.session.commit()
            flash('Medicine updated successfully!', 'success')
            return redirect(url_for('pharmacy.index'))
        except Exception as e:
            db.session.rollback()
            flash('Error updating medicine: ' + str(e), 'danger')
    return render_template('pharmacy/medicine_form.html', medicine=med, edit=True)

@pharmacy_bp.route('/medicines/<int:med_id>/restock', methods=['POST'])
@login_required
def restock_medicine(med_id):
    med = Medicine.query.get_or_404(med_id)
    qty = int(request.form.get('quantity', 0))
    med.stock_quantity += qty
    db.session.commit()
    flash(f'Restocked {qty} units of {med.name}', 'success')
    return redirect(url_for('pharmacy.index'))

# ---- Prescriptions ----
@pharmacy_bp.route('/prescriptions')
@login_required
def prescriptions():
    presc_list = Prescription.query.order_by(Prescription.created_at.desc()).all()
    return render_template('pharmacy/prescriptions.html', prescriptions=presc_list)

@pharmacy_bp.route('/prescriptions/new', methods=['GET', 'POST'])
@login_required
def new_prescription():
    patients = Patient.query.all()
    doctors = Doctor.query.all()
    medicines = Medicine.query.filter(Medicine.stock_quantity > 0).all()
    if request.method == 'POST':
        try:
            presc = Prescription(
                patient_id=int(request.form['patient_id']),
                doctor_id=int(request.form['doctor_id']),
                notes=request.form.get('notes'),
                status='pending'
            )
            db.session.add(presc)
            db.session.flush()
            med_ids = request.form.getlist('medicine_id[]')
            quantities = request.form.getlist('quantity[]')
            dosages = request.form.getlist('dosage[]')
            frequencies = request.form.getlist('frequency[]')
            durations = request.form.getlist('duration[]')
            for i in range(len(med_ids)):
                if med_ids[i]:
                    item = PrescriptionItem(
                        prescription_id=presc.id,
                        medicine_id=int(med_ids[i]),
                        quantity=int(quantities[i]),
                        dosage=dosages[i],
                        frequency=frequencies[i],
                        duration=durations[i] if i < len(durations) else ''
                    )
                    db.session.add(item)
            db.session.commit()
            flash('Prescription created!', 'success')
            return redirect(url_for('pharmacy.prescriptions'))
        except Exception as e:
            db.session.rollback()
            flash('Error: ' + str(e), 'danger')
    return render_template('pharmacy/prescription_form.html', patients=patients, doctors=doctors, medicines=medicines)

@pharmacy_bp.route('/prescriptions/<int:presc_id>/dispense', methods=['POST'])
@login_required
def dispense_prescription(presc_id):
    presc = Prescription.query.get_or_404(presc_id)
    try:
        total = 0
        for item in presc.items:
            if item.medicine.stock_quantity < item.quantity:
                flash(f'Insufficient stock for {item.medicine.name}', 'danger')
                return redirect(url_for('pharmacy.prescriptions'))
            item.medicine.stock_quantity -= item.quantity
            total += item.quantity * item.medicine.unit_price
        
        sale = PharmacySale(
            prescription_id=presc.id,
            patient_id=presc.patient_id,
            total_amount=total,
            payment_status='paid'
        )
        db.session.add(sale)
        db.session.flush()
        
        for item in presc.items:
            si = PharmacySaleItem(
                sale_id=sale.id,
                medicine_id=item.medicine_id,
                quantity=item.quantity,
                unit_price=item.medicine.unit_price,
                total_price=item.quantity * item.medicine.unit_price
            )
            db.session.add(si)
        
        presc.status = 'dispensed'
        presc.dispensed_at = datetime.utcnow()
        db.session.commit()
        flash('Prescription dispensed successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error dispensing: ' + str(e), 'danger')
    return redirect(url_for('pharmacy.prescriptions'))

# ---- Sales ----
@pharmacy_bp.route('/sales')
@login_required
def sales():
    sales_list = PharmacySale.query.order_by(PharmacySale.created_at.desc()).all()
    total_revenue = sum(s.total_amount for s in sales_list if s.payment_status == 'paid')
    return render_template('pharmacy/sales.html', sales=sales_list, total_revenue=total_revenue)

from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from models import db, Patient, Doctor, Appointment, Billing
from sqlalchemy import func
from datetime import datetime, timedelta

reports_bp = Blueprint('reports', __name__, url_prefix='/reports')

@reports_bp.route('/')
@login_required
def index():
    # Get date range from request
    days = request.args.get('days', 30, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Patient statistics
    total_patients = Patient.query.count()
    new_patients = Patient.query.filter(Patient.created_at >= start_date).count()
    
    # Appointment statistics
    total_appointments = Appointment.query.filter(Appointment.created_at >= start_date).count()
    completed_appointments = Appointment.query.filter(
        Appointment.status == 'completed',
        Appointment.created_at >= start_date
    ).count()
    cancelled_appointments = Appointment.query.filter(
        Appointment.status == 'cancelled',
        Appointment.created_at >= start_date
    ).count()
    
    # Revenue statistics
    total_revenue = db.session.query(func.sum(Billing.amount)).filter(
        Billing.status == 'paid',
        Billing.paid_at >= start_date
    ).scalar() or 0
    
    pending_revenue = db.session.query(func.sum(Billing.amount)).filter(
        Billing.status == 'pending',
        Billing.created_at >= start_date
    ).scalar() or 0
    
    # Doctor statistics
    doctor_appointments = db.session.query(
        Doctor.id,
        Doctor.user.full_name,
        func.count(Appointment.id).label('appointment_count')
    ).join(Appointment).filter(
        Appointment.created_at >= start_date
    ).group_by(Doctor.id).all()
    
    stats = {
        'total_patients': total_patients,
        'new_patients': new_patients,
        'total_appointments': total_appointments,
        'completed_appointments': completed_appointments,
        'cancelled_appointments': cancelled_appointments,
        'total_revenue': round(total_revenue, 2),
        'pending_revenue': round(pending_revenue, 2),
        'period_days': days
    }
    
    return render_template('reports/index.html', stats=stats, doctor_appointments=doctor_appointments)

@reports_bp.route('/patient/<int:patient_id>')
@login_required
def patient_report(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    # Get patient's appointments
    appointments = Appointment.query.filter_by(patient_id=patient_id).all()
    
    # Get patient's bills
    bills = Billing.query.filter_by(patient_id=patient_id).all()
    
    # Calculate statistics
    total_spent = sum(b.amount for b in bills if b.status == 'paid')
    pending_amount = sum(b.amount for b in bills if b.status == 'pending')
    appointment_count = len(appointments)
    completed_count = len([a for a in appointments if a.status == 'completed'])
    
    stats = {
        'total_spent': round(total_spent, 2),
        'pending_amount': round(pending_amount, 2),
        'total_appointments': appointment_count,
        'completed_appointments': completed_count
    }
    
    return render_template('reports/patient_report.html', 
                         patient=patient, 
                         stats=stats,
                         appointments=appointments,
                         bills=bills)

@reports_bp.route('/doctor/<int:doctor_id>')
@login_required
def doctor_report(doctor_id):
    from models import Doctor
    doctor = Doctor.query.get_or_404(doctor_id)
    
    # Get doctor's appointments
    appointments = Appointment.query.filter_by(doctor_id=doctor_id).all()
    
    # Calculate statistics
    total_appointments = len(appointments)
    completed_appointments = len([a for a in appointments if a.status == 'completed'])
    cancelled_appointments = len([a for a in appointments if a.status == 'cancelled'])
    scheduled_appointments = len([a for a in appointments if a.status == 'scheduled'])
    
    stats = {
        'total_appointments': total_appointments,
        'completed_appointments': completed_appointments,
        'cancelled_appointments': cancelled_appointments,
        'scheduled_appointments': scheduled_appointments
    }
    
    return render_template('reports/doctor_report.html', 
                         doctor=doctor, 
                         stats=stats,
                         appointments=appointments)

@reports_bp.route('/api/appointment-trends')
@login_required
def appointment_trends():
    days = request.args.get('days', 30, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Get daily appointment counts
    trends = db.session.query(
        func.date(Appointment.created_at).label('date'),
        Appointment.status,
        func.count(Appointment.id).label('count')
    ).filter(
        Appointment.created_at >= start_date
    ).group_by(
        func.date(Appointment.created_at),
        Appointment.status
    ).all()
    
    data = {}
    for trend in trends:
        date_str = str(trend.date)
        if date_str not in data:
            data[date_str] = {}
        data[date_str][trend.status] = trend.count
    
    return jsonify(data)

@reports_bp.route('/api/revenue-trends')
@login_required
def revenue_trends():
    days = request.args.get('days', 30, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Get daily revenue
    trends = db.session.query(
        func.date(Billing.created_at).label('date'),
        Billing.status,
        func.sum(Billing.amount).label('total')
    ).filter(
        Billing.created_at >= start_date
    ).group_by(
        func.date(Billing.created_at),
        Billing.status
    ).all()
    
    data = {}
    for trend in trends:
        date_str = str(trend.date)
        if date_str not in data:
            data[date_str] = {}
        data[date_str][trend.status] = round(trend.total, 2)
    
    return jsonify(data)

from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import db, Appointment, Patient, Doctor, Billing, Service
from datetime import datetime, timedelta
from sqlalchemy import and_

appointments_bp = Blueprint('appointments', __name__, url_prefix='/appointments')

@appointments_bp.route('/')
@login_required
def list_appointments():
    status = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    
    query = Appointment.query
    
    if status:
        query = query.filter_by(status=status)
    
    appointments = query.order_by(Appointment.appointment_date.desc()).paginate(page=page, per_page=10)
    return render_template('appointments/list.html', appointments=appointments, status_filter=status)

@appointments_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new_appointment():
    patients = Patient.query.all()
    doctors = Doctor.query.all()
    
    if request.method == 'POST':
        try:
            patient_id = int(request.form.get('patient_id'))
            doctor_id = int(request.form.get('doctor_id'))
            appointment_datetime = datetime.strptime(
                request.form.get('appointment_date') + ' ' + request.form.get('appointment_time'),
                '%Y-%m-%d %H:%M'
            )
            reason = request.form.get('reason')
            
            # Check for double booking
            existing = Appointment.query.filter(
                and_(
                    Appointment.doctor_id == doctor_id,
                    Appointment.appointment_date == appointment_datetime,
                    Appointment.status != 'cancelled'
                )
            ).first()
            
            if existing:
                flash('Doctor is already booked at this time', 'danger')
                return redirect(url_for('appointments.new_appointment'))
            
            appointment = Appointment(
                patient_id=patient_id,
                doctor_id=doctor_id,
                appointment_date=appointment_datetime,
                reason=reason,
                status='scheduled'
            )
            
            db.session.add(appointment)
            db.session.commit()
            
            flash('Appointment scheduled successfully!', 'success')
            return redirect(url_for('appointments.list_appointments'))
        except Exception as e:
            db.session.rollback()
            flash('Error scheduling appointment: ' + str(e), 'danger')
            return redirect(url_for('appointments.new_appointment'))
    
    return render_template('appointments/form.html', patients=patients, doctors=doctors)

@appointments_bp.route('/<int:appointment_id>')
@login_required
def view_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    return render_template('appointments/view.html', appointment=appointment)

@appointments_bp.route('/<int:appointment_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    patients = Patient.query.all()
    doctors = Doctor.query.all()
    
    if request.method == 'POST':
        try:
            new_date = datetime.strptime(
                request.form.get('appointment_date') + ' ' + request.form.get('appointment_time'),
                '%Y-%m-%d %H:%M'
            )
            
            # Check for double booking (excluding current appointment)
            existing = Appointment.query.filter(
                and_(
                    Appointment.id != appointment_id,
                    Appointment.doctor_id == appointment.doctor_id,
                    Appointment.appointment_date == new_date,
                    Appointment.status != 'cancelled'
                )
            ).first()
            
            if existing:
                flash('Doctor is already booked at this time', 'danger')
                return redirect(url_for('appointments.edit_appointment', appointment_id=appointment_id))
            
            appointment.appointment_date = new_date
            appointment.reason = request.form.get('reason')
            appointment.notes = request.form.get('notes')
            
            db.session.commit()
            
            flash('Appointment updated successfully!', 'success')
            return redirect(url_for('appointments.view_appointment', appointment_id=appointment.id))
        except Exception as e:
            db.session.rollback()
            flash('Error updating appointment: ' + str(e), 'danger')
    
    return render_template('appointments/form.html', 
                         appointment=appointment, 
                         patients=patients, 
                         doctors=doctors,
                         edit=True)

@appointments_bp.route('/<int:appointment_id>/complete', methods=['POST'])
@login_required
def complete_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    try:
        appointment.status = 'completed'
        appointment.notes = request.form.get('notes', '')
        db.session.commit()
        flash('Appointment marked as completed!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error completing appointment: ' + str(e), 'danger')
    
    return redirect(url_for('appointments.view_appointment', appointment_id=appointment.id))

@appointments_bp.route('/<int:appointment_id>/cancel', methods=['POST'])
@login_required
def cancel_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    try:
        appointment.status = 'cancelled'
        db.session.commit()
        flash('Appointment cancelled!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error cancelling appointment: ' + str(e), 'danger')
    
    return redirect(url_for('appointments.view_appointment', appointment_id=appointment.id))

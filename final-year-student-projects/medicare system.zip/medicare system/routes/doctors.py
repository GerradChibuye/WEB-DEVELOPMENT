from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db, Doctor, User
from datetime import datetime

doctors_bp = Blueprint('doctors', __name__, url_prefix='/doctors')

@doctors_bp.route('/')
@login_required
def list_doctors():
    search = request.args.get('search', '')
    page = request.args.get('page', 1, type=int)
    
    query = Doctor.query.join(User)
    
    if search:
        query = query.filter(
            (User.full_name.ilike(f'%{search}%')) |
            (Doctor.specialization.ilike(f'%{search}%')) |
            (Doctor.license_number.ilike(f'%{search}%'))
        )
    
    doctors = query.paginate(page=page, per_page=10)
    return render_template('doctors/list.html', doctors=doctors, search=search)

@doctors_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new_doctor():
    if request.method == 'POST':
        try:
            # Create user account first
            user = User(
                username=request.form.get('username'),
                email=request.form.get('email'),
                full_name=request.form.get('full_name'),
                role='doctor'
            )
            user.set_password(request.form.get('password'))
            
            db.session.add(user)
            db.session.flush()
            
            # Create doctor profile
            doctor = Doctor(
                user_id=user.id,
                specialization=request.form.get('specialization'),
                license_number=request.form.get('license_number'),
                phone=request.form.get('phone'),
                available_slots=int(request.form.get('available_slots', 10))
            )
            
            db.session.add(doctor)
            db.session.commit()
            
            flash('Doctor registered successfully!', 'success')
            return redirect(url_for('doctors.list_doctors'))
        except Exception as e:
            db.session.rollback()
            flash('Error registering doctor: ' + str(e), 'danger')
            return redirect(url_for('doctors.new_doctor'))
    
    return render_template('doctors/form.html')

@doctors_bp.route('/<int:doctor_id>')
@login_required
def view_doctor(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    return render_template('doctors/view.html', doctor=doctor)

@doctors_bp.route('/<int:doctor_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_doctor(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    
    if request.method == 'POST':
        try:
            doctor.user.full_name = request.form.get('full_name')
            doctor.user.email = request.form.get('email')
            doctor.specialization = request.form.get('specialization')
            doctor.license_number = request.form.get('license_number')
            doctor.phone = request.form.get('phone')
            doctor.available_slots = int(request.form.get('available_slots', 10))
            
            db.session.commit()
            
            flash('Doctor updated successfully!', 'success')
            return redirect(url_for('doctors.view_doctor', doctor_id=doctor.id))
        except Exception as e:
            db.session.rollback()
            flash('Error updating doctor: ' + str(e), 'danger')
    
    return render_template('doctors/form.html', doctor=doctor)

@doctors_bp.route('/<int:doctor_id>/delete', methods=['POST'])
@login_required
def delete_doctor(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    
    try:
        user_id = doctor.user_id
        db.session.delete(doctor)
        user = User.query.get(user_id)
        if user:
            db.session.delete(user)
        db.session.commit()
        flash('Doctor deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting doctor: ' + str(e), 'danger')
    
    return redirect(url_for('doctors.list_doctors'))

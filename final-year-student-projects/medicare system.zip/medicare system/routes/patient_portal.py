from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db, Appointment, Patient, Doctor
from datetime import datetime
from sqlalchemy import and_

patient_portal_bp = Blueprint('patient_portal', __name__, url_prefix='/portal')

@patient_portal_bp.route('/')
@login_required
def index():
    if current_user.role != 'patient':
        return redirect(url_for('dashboard.index'))
    patient = Patient.query.filter_by(user_id=current_user.id).first()
    if not patient:
        flash('Patient profile not found.', 'danger')
        return redirect(url_for('auth.logout'))
    upcoming = Appointment.query.filter(
        Appointment.patient_id == patient.id,
        Appointment.status == 'scheduled'
    ).order_by(Appointment.appointment_date).all()
    past = Appointment.query.filter(
        Appointment.patient_id == patient.id,
        Appointment.status != 'scheduled'
    ).order_by(Appointment.appointment_date.desc()).limit(10).all()
    return render_template('patient_portal/index.html', patient=patient, upcoming=upcoming, past=past)

@patient_portal_bp.route('/book', methods=['GET', 'POST'])
@login_required
def book_appointment():
    if current_user.role != 'patient':
        return redirect(url_for('dashboard.index'))
    patient = Patient.query.filter_by(user_id=current_user.id).first()
    doctors = Doctor.query.all()
    if request.method == 'POST':
        try:
            doctor_id = int(request.form.get('doctor_id'))
            appt_dt = datetime.strptime(
                request.form.get('appointment_date') + ' ' + request.form.get('appointment_time'),
                '%Y-%m-%d %H:%M'
            )
            reason = request.form.get('reason')
            existing = Appointment.query.filter(
                and_(
                    Appointment.doctor_id == doctor_id,
                    Appointment.appointment_date == appt_dt,
                    Appointment.status != 'cancelled'
                )
            ).first()
            if existing:
                flash('That time slot is already taken. Please choose another.', 'danger')
                return redirect(url_for('patient_portal.book_appointment'))
            appt = Appointment(
                patient_id=patient.id,
                doctor_id=doctor_id,
                appointment_date=appt_dt,
                reason=reason,
                status='scheduled',
                booked_by_patient=True
            )
            db.session.add(appt)
            db.session.commit()
            flash('Your appointment has been booked successfully! We look forward to seeing you.', 'success')
            return redirect(url_for('patient_portal.index'))
        except Exception as e:
            db.session.rollback()
            flash('Error booking appointment: ' + str(e), 'danger')
    return render_template('patient_portal/book.html', doctors=doctors)

@patient_portal_bp.route('/cancel/<int:appt_id>', methods=['POST'])
@login_required
def cancel_appointment(appt_id):
    if current_user.role != 'patient':
        return redirect(url_for('dashboard.index'))
    patient = Patient.query.filter_by(user_id=current_user.id).first()
    appt = Appointment.query.get_or_404(appt_id)
    if appt.patient_id != patient.id:
        flash('Unauthorized', 'danger')
        return redirect(url_for('patient_portal.index'))
    appt.status = 'cancelled'
    db.session.commit()
    flash('Appointment cancelled.', 'success')
    return redirect(url_for('patient_portal.index'))

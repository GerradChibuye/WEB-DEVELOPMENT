from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models import db, Patient, Doctor, Appointment, Billing, User, Medicine
from sqlalchemy import func
from datetime import datetime, timedelta

dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/')

@dashboard_bp.route('/')
@login_required
def index():
    if current_user.role == 'patient':
        from flask import redirect, url_for
        return redirect(url_for('patient_portal.index'))
    
    total_patients = Patient.query.count()
    total_doctors = Doctor.query.count()
    total_appointments = Appointment.query.count()
    pending_billings = Billing.query.filter_by(status='pending').count()
    total_revenue = db.session.query(func.sum(Billing.amount)).filter(Billing.status == 'paid').scalar() or 0
    total_medicines = Medicine.query.count()
    
    recent_appointments = Appointment.query.order_by(Appointment.created_at.desc()).limit(5).all()
    
    today = datetime.utcnow().date()
    todays_appointments = Appointment.query.filter(
        func.date(Appointment.appointment_date) == today
    ).all()
    
    low_stock_medicines = Medicine.query.filter(Medicine.stock_quantity <= Medicine.reorder_level).all()
    
    stats = {
        'total_patients': total_patients,
        'total_doctors': total_doctors,
        'total_appointments': total_appointments,
        'pending_billings': pending_billings,
        'total_revenue': round(total_revenue, 2),
        'total_medicines': total_medicines
    }
    
    return render_template('dashboard/index.html',
                           stats=stats,
                           recent_appointments=recent_appointments,
                           todays_appointments=todays_appointments,
                           low_stock_medicines=low_stock_medicines)

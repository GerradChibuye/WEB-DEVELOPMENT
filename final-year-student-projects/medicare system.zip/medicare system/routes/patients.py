from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import db, Patient
from datetime import datetime

patients_bp = Blueprint('patients', __name__, url_prefix='/patients')

@patients_bp.route('/')
@login_required
def list_patients():
    search = request.args.get('search', '')
    page = request.args.get('page', 1, type=int)
    
    query = Patient.query
    
    if search:
        query = query.filter(
            (Patient.first_name.ilike(f'%{search}%')) |
            (Patient.last_name.ilike(f'%{search}%')) |
            (Patient.email.ilike(f'%{search}%')) |
            (Patient.phone.ilike(f'%{search}%'))
        )
    
    patients = query.paginate(page=page, per_page=10)
    return render_template('patients/list.html', patients=patients, search=search)

@patients_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new_patient():
    if request.method == 'POST':
        try:
            patient = Patient(
                first_name=request.form.get('first_name'),
                last_name=request.form.get('last_name'),
                email=request.form.get('email'),
                phone=request.form.get('phone'),
                date_of_birth=datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date(),
                gender=request.form.get('gender'),
                address=request.form.get('address'),
                medical_history=request.form.get('medical_history')
            )
            
            db.session.add(patient)
            db.session.commit()
            
            flash('Patient registered successfully!', 'success')
            return redirect(url_for('patients.list_patients'))
        except Exception as e:
            db.session.rollback()
            flash('Error registering patient: ' + str(e), 'danger')
            return redirect(url_for('patients.new_patient'))
    
    return render_template('patients/form.html')

@patients_bp.route('/<int:patient_id>')
@login_required
def view_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    return render_template('patients/view.html', patient=patient)

@patients_bp.route('/<int:patient_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    if request.method == 'POST':
        try:
            patient.first_name = request.form.get('first_name')
            patient.last_name = request.form.get('last_name')
            patient.email = request.form.get('email')
            patient.phone = request.form.get('phone')
            patient.date_of_birth = datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date()
            patient.gender = request.form.get('gender')
            patient.address = request.form.get('address')
            patient.medical_history = request.form.get('medical_history')
            
            db.session.commit()
            
            flash('Patient updated successfully!', 'success')
            return redirect(url_for('patients.view_patient', patient_id=patient.id))
        except Exception as e:
            db.session.rollback()
            flash('Error updating patient: ' + str(e), 'danger')
    
    return render_template('patients/form.html', patient=patient)

@patients_bp.route('/<int:patient_id>/delete', methods=['POST'])
@login_required
def delete_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    try:
        db.session.delete(patient)
        db.session.commit()
        flash('Patient deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting patient: ' + str(e), 'danger')
    
    return redirect(url_for('patients.list_patients'))
